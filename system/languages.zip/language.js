﻿var arrayLanguages = [];
var af_ZA = {file:"Lêer", new:"Nuwe", open:"Oop", save:"Red",import:"Invoer", export:"Uitvoer", print:"Druk", exit:"Uitgang",edit:"Wysig", undo:"Ongedaan", redo:"Oordoen", copy:"Kopie",cut:"Sny", paste:"Plak", search:"Soek", find:"Vind",findnext:"Vind Volgende", findprev:"Vind Prev", replace:"vervang",replaceall:"Alle vervang", view:"siening", markline:"merk lyn", deleteline:"verwyder lyn",newline:"nuwe lyn",inserttab:"Tab insetsel", fold:"vou", unfold:"ontvou", foldall:"Alle vou", unfoldall:"ontvou Alle",tools:"Gereedskap",comment:"kommentaar", uncomment:"Uncomment", marktext:"merk teks", removemark:"verwyder merk", removeallmark:"Verwyder alle merk",autoformat:"Auto Format",configuration:"konfigurasie", options:"Opsies", help:"Hulp", language:"sprog"};



var ar_AA = {file:"ملف", new:"جديد", open:"فتح", save:"حفظ",import:"استيراد", export:"تصدير", print:"طباعة", exit:"ترك",edit:"تحرير", undo:"فك", redo:"طبعة جديدة'", copy:"نسخة",cut:"قطع", paste:"قلادة", search:"بحث", find:"اكتشاف",findnext:"بحث عن التالي", findprev:"البحث السابق", replace:"استبدل",replaceall:"استبدال جميع", view:"رأي", markline:"علامة الخط", deleteline:"حذف الخط",newline:"نيو لاين",inserttab:"علامة التبويب إدراج", fold:"طية", unfold:"كشف", foldall:"جميع أضعاف", unfoldall:"تتكشف جميع'",tools:"أدوات",comment:"تعليق", uncomment:"غير تعليق", marktext:"نص علامة", removemark:"إزالة كافة", removeallmark:"إزالة جميع الأقسام",autoformat:"تنسيق السيارات",configuration:"ترتيب", options:"خيارات", help:"مساعدة", language:"لغة"};

var cs_CZ = {file:"Soubor", new:"Nový", open:"Otevřený", save:"Ušetřit",import:"Dovozní", export:"Vývozní", print:"Tisk", exit:"Výjezd",edit:"Editovat", undo:"Zrušit", redo:"Předělat", copy:"kopie",cut:"řez", paste:"Pasta", search:"vyhledávání", find:"najít",findnext:"najít další", findprev:"najít Předchozí", replace:"vyměnit",replaceall:"nahradit vše", view:"pohled", markline:"Mark linka", deleteline:"Smazat řádek",newline:"Nový režim Line",inserttab:"Vložit Tab", fold:"složit", unfold:"rozvinout", foldall:"Přeložte Vše", unfoldall:"rozvinout vše",tools:"Nářadí",comment:"komentář", uncomment:"odkomentovat", marktext:"Značka textu", removemark:"Odstranit Mark", removeallmark:"Odebrat vše Mark",autoformat:"تنسيق السيارات",configuration:"Konfigurace", options:"Možnosti", help:"Pomoc", language:"Jazyk"};

var da_DA = { file:"Fil", new:"Ny", open:"Åbent", save:"Gem", import:"Import", export:"Eksport", print:"Tryk", exit:"Frakørsel", edit:"Rediger", undo:"Fortryde", redo:"Redo", copy:"kopi", cut:"Skåret", paste:"Pasta", search:"Søg", find:"finde", findnext:"Find næste", findprev:"Find forrige", replace:"udskifte", replaceall:"Erstat alle", view:"udsigt", markline:"Mark Linje", deleteline:"Slet Linie", newline:"ny linje", inserttab:"Indsæt Tab", fold:"folde", unfold:"udfolde", foldall:"fold alle", unfoldall:"Udfold alle", tools:"Værktøjer", comment:"kommentar", uncomment:"Afkommentér", marktext:"Mark tekst", removemark:"Fjern Mark", removeallmark:"Fjern alle Mark", autoformat:"Auto Format", configuration:"Konfiguration", options:"Optioner", help:"Hjælpe",language:"sprog"};

var de_DE = { file:"Datei", new:"Neu", open:"Geöffnet", save:"Sparen", import:"Einfuhr", export:"Ausfuhr", print:"Druck", exit:"Verlassen", edit:"Bearbeiten", undo:"Rückgängig machen", redo:"Wiederholen", copy:"Kopie", cut:"Schnitt", paste:"Halskette", search:"Suche", find:"finden", findnext:"Weitersuchen", findprev:"finden Sie zurück", replace:"ersetzen", replaceall:"Alle ersetzen", view:"Ansicht", markline:"Mark Linie", deleteline:"Zeile lÃ¶schen", newline:"neue Zeile", inserttab:"Tab einfügen", fold:"falten", unfold:"entfalten", foldall:"Alle falten", unfoldall:"Alles ausklappen", tools:"Tools", comment:"Kommentar", uncomment:"Uncomment", marktext:"Marke Text", removemark:"entfernen Mark", removeallmark:"Alle entfernen Mark", autoformat:"Auto Format", configuration:"Konfiguration", options:"Optionen", help:"Hilfe",language:"Sprache"};

var el_GR = { file:"αρχείο", new:"νέος", open:"Aνοιχτό", save:"εκτός", import:"εισαγωγή", export:"εξαγωγή", print:"Εκτύπωση", exit:"έξοδος‚", edit:"Επεξεργασία", undo:"Επεξεργασία", redo:"ξανακάνω", copy:"αντίγραφο", cut:"κόψιμο", paste:"πάστα", search:"έρευνα", find:"βρίσκω", findnext:"βρείτε Επόμενο", findprev:"βρείτε Προηγούμενο", replace:"Αντικαταστήστε", replaceall:"Αντικατάσταση όλων", view:"θέα", markline:"ισάλου γραμμής", deleteline:"Διαγραφή γραμμής", newline:"νέας Γραμμής", inserttab:"Εισαγωγή Tab", fold:"πτυχή", unfold:"Ξεδιπλώστε", foldall:"Διπλώστε", unfoldall:"Ξεδιπλώστε Όλα", tools:"εργαλεία", comment:"σχόλιο", uncomment:"αποσχολιάσετε", marktext:"Mark Κείμενο", removemark:"Κατάργηση Mark", removeallmark:"Κατάργηση όλων Mark", autoformat:"Αυτόματο φορμά", configuration:"διαμόρφωση", options:"Επιλογές", help:"βοήθεια",language:"γλώσσα"};

var es_ES = { file:"Fichero", new:"Nuevo", open:"Abierto", save:"Guardar", import:"Importación", export:"Exportación", print:"Impresión", exit:"Salir", edit:"Editar", undo:"Deshacer", redo:"Rehacer", copy:"Copiar", cut:"Cortar", paste:"Pegar", search:"búsqueda", find:"encontrar", findnext:"Buscar siguiente", findprev:"Encuentra Anterior", replace:"reemplazar", replaceall:"Reemplaza Todo", view:"vista", markline:"Marcos Línea", deleteline:"borrar Line", newline:"Nueva Línea", inserttab:"Insertar pestaña", fold:"plegar", unfold:"desplegar", foldall:"Dobla Todo", unfoldall:"Desdoble Todo", tools:"Herramientas", comment:"comentario", uncomment:"Elimine el comentario", marktext:"Marca Texto", removemark:"Quite la marca", removeallmark:"Quitar todo Marcos", autoformat:"Formato automático", configuration:"Configuración", options:"Opciones", help:"Ayuda",language:"Idioma"};


var en_US = {file:"file", new:"New", open:"Open", save:"Save",import:"Import", export:"Export", print:"Print", exit:"exit",edit:"Edit", undo:"Undo", redo:"Redo", copy:"Copy",cut:"Cut", paste:"Paste", search:"Search", find:"Find",findnext:"Find Next", findprev:"Find Prev", replace:"Replace",replaceall:"Replace All", view:"View", markline:"Mark Line", deleteline:"Delete Line",newline:"New Line",inserttab:"Insert Tab", fold:"Fold", unfold:"Unfold", foldall:"Fold All", unfoldall:"Unfold All",tools:"Tools",comment:"comment", uncomment:"Uncomment", marktext:"Mark Text", removemark:"Remove Mark", removeallmark:"Remove All Mark",autoformat:"Auto Format",configuration:"Configuration", options:"Options", help:"Help",language:"Language"};


var fa_IR = {file:"پرونده", new:"جدید", open:"باز", save:"نجات",import:"واردات", export:"صادرات", print:"چاپ", exit:"خروج",edit:"ویرایش", undo:"خنثی کردن", redo:"ازنو", copy:"نسخه",cut:"برش", paste:"خمیر", search:"جستجو", find:"پیدا کردن",findnext:"یافتن بعدی", findprev:"یافتن قبلی", replace:"جایگزین کردن",replaceall:"جایگزینی همه", view:"نظر", markline:"علامت گذاری به عنوان خط", deleteline:"حذف خط",newline:"خط جدید",inserttab:"درج برگه", fold:"تاه", unfold:"اشکار شدن", foldall:"ریختن (فولد) همه", unfoldall:"آشکار شدن همه",tools:"ابزار",comment:"توضیح", uncomment:"کامنت", marktext:"علامت گذاری به عنوان متن", removemark:"حذف علامت گذاری به عنوان", removeallmark:"حذف همه علامت گذاری به عنوان",autoformat:"فرمت خودکار",configuration:"پیکر بندی", options:"گزینه", help:"کمک",language:"زبان"};


var fr_FR = { file:"Fichier", new:"Nouveau", open:"Ouvert", save:"Sauver", import:"Importation", export:"Exportation", print:"Imprimer", exit:"Laisser", edit:"Éditer", undo:"Défaire", redo:"Refaire", copy:"Copie", cut:"Coupe", paste:"Collier", search:"recherche", find:"trouver", findnext:"Trouver Suivant", findprev:"Trouver Précéden", replace:"remplacer", replaceall:"remplacer tout", view:"vue", markline:"Mark ligne", deleteline:"supprimer ligne", newline:"nouvelle Ligne", inserttab:"Insérer un onglet", fold:"plier", unfold:"déplier", foldall:"Pliez Tous", unfoldall:"déplier Tous", tools:"Outils", comment:"commentaire", uncomment:"Uncomment", marktext:"Mark texte", removemark:"Retirer Mark", removeallmark:"Supprimer tout Mark", autoformat:"Auto Format", configuration:"Configuration", options:"Options", help:"Aidez-moi",language:"langue"};


var he_IL = { file:"קובץ", new:"חדש", open:"פתוח", save:"להציל", import:"יבוא", export:"יצוא", print:"הדפסה", exit:"יציאה", edit:"עריכה", undo:"לבטל", redo:"שוב", copy:"עותק", cut:"לחתוך", paste:"דבק", search:"חיפוש", find:"מצא", findnext:"חפש את הבא", findprev:"מצא קודם", replace:"החלף", replaceall:"החלף הכל", view:"צפה ב", markline:"מארק קו", deleteline:"מחיקת קו", newline:"קו חדש", inserttab:"הכנס Tab", fold:"מקפלים", unfold:"לפתוח", foldall:"מקפלים כל", unfoldall:"לפתוח כל", tools:"כלים", comment:"תגובה", uncomment:"בטלהערה", marktext:"מארק טקסט", removemark:"הסר מארק", removeallmark:"הסר את כל מרק", autoformat:"ורמט אוטומטי", configuration:"תצורה", options:"אפשרויות", help:"לעזור",language:"שפה"};

var hi_IN = { file:"फ़ाइल", new:"नई", open:"खुला है", save:"बचाना", import:"आयात", export:"निर्यात", print:"छाप", exit:"'बाहर जाएं'", edit:"संपादित", undo:"पूर्ववत", redo:"'फिर से करना", copy:"प्रतिलिपि", cut:"कटौती", paste:"पेस्ट", search:"खोज", find:"खोज", findnext:"दूसरा खोजो", findprev:"पिछला लगाएं", replace:"बदलें", replaceall:"सबको बदलो", view:"देखें", markline:"मार्क रेखा", deleteline:"लाइन को हटाना", newline:"नई लाइन", inserttab:"सम्मिलित करें टैब", fold:"मोड़ो", unfold:"उधेड़ना", foldall:"सभी मोड़ो", unfoldall:"सभी उधेड़ना", tools:"उपकरण", comment:"टिप्पणी", uncomment:"अनकमेंट", marktext:"मार्क पाठ", removemark:"मार्क निकालें", removeallmark:"सभी मार्क निकालें", autoformat:"स्वत: स्वरूप", configuration:"विन्यास", options:"विकल्पों", help:"मदद",language:"भाषा"};

var hr_HR = { file:"Datoteka", new:"Novi", open:"Otvorena", save:"Spasiti", import:"Uvoz", export:"Izvoz", print:"Otisak", exit:"Izlaz", edit:"Uredi", undo:"Odvezati", redo:"Preurediti", copy:"Kopija", cut:"Rez", paste:"Tijesto", search:"pretraživanje", find:"pronaći", findnext:"Traži sljedeće", findprev:"Nađi Prethodna", replace:"zamijeniti", replaceall:"Zamijeni sve", view:"pogled", markline:"Označi linija", deleteline:"Brisanje Linija", newline:"Novi linija", inserttab:"Umetnite karticu", fold:"saviti", unfold:"razmotati", foldall:"fold Sve", unfoldall:"zatvori sve", tools:"Alat", comment:"komentar", uncomment:"Uncomment", marktext:"Označite tekst", removemark:"Uklonite Mark", removeallmark:"Ukloni sve Markk", autoformat:"Auto Format", configuration:"Konfiguracija", options:"Opcije", help:"Pomoći",language:"govor"};


var hu_HU = { file:"Akta", new:"Új", open:"Nyitva", save:"Megment", import:"Behozatali", export:"Kiviteli", print:"Nyomtatás", exit:"Kijárat", edit:"Szerkesztés", undo:"Kibont", redo:"Újra", copy:"Másolat", cut:"Vágott", paste:"Paszta", search:"keresés", find:"talál", findnext:"Következő keresése", findprev:"Keresse Előző", replace:"Cserélje", replaceall:"Az összes Cserélje", view:"kilátás", markline:"jelzésre", deleteline:"sor törlése", newline:"új vonal", inserttab:"Helyezze Tab", fold:"Hajtsa", unfold:"kibontakozik", foldall:"Hajtsa Összes", unfoldall:"Hajtsuk ki minden", tools:"Szerszámok", comment:"megjegyzés", uncomment:"megjegyzésből", marktext:"Mark szöveg", removemark:"Távolítsuk el Mark", removeallmark:"Minden eltávolítása Mark", autoformat:"Auto Format", configuration:"Konfiguráció", options:"Opciók", help:"Segít",language:"Nyelv"};

var id_ID = { file:"Berkas", new:"Baru", open:"Terbuka", save:"Menyimpan", import:"Impor", export:"Ekspor", print:"Mencetak", exit:"Keluar", edit:"Mengedit", undo:"Membuka", redo:"Mengulang", copy:"Salinan", cut:"Memotong", paste:"Pasta", search:"pencarian", find:"menemukan", findnext:"Cari Berikutnya", findprev:"Cari Prev", replace:"menggantikan", replaceall:"Ganti Semua", view:"pandangan", markline:"Mark Baris", deleteline:"Hapus Jalur", newline:"new Garis", inserttab:"Masukkan Tab", fold:"melipat", unfold:"terhampar", foldall:"lipat Semua", unfoldall:"terungkap Semua", tools:"Alat", comment:"komentar", uncomment:"tanda komentar", marktext:"Mark Teks", removemark:"Hapus Mark", removeallmark:"Hapus Semua Mark", autoformat:"Auto Format", configuration:"Konfigurasi", options:"Pilihan", help:"Menbantu",language:"bahasa"};

var it_IT = { file:"File", new:"Nuovo", open:"Aperto", save:"Salvare", import:"Importazione", export:"Esportazione", print:"Stampa", exit:"Lasciare", edit:"Modifica", undo:"Disfare", redo:"Rifare", copy:"Copia", cut:"Taglio", paste:"Collana", search:"ricerca", find:"trovare", findnext:"Trova successivo", findprev:"Trova Prev", replace:"sostituire", replaceall:"Sostituisci tutto", view:"vista", markline:"Mark Linea", deleteline:"Elimina Linea", newline:"Nuova Linea", inserttab:"inserimento separatore", fold:"piega", unfold:"spiegare", foldall:"Piegare tutto", unfoldall:"spiegare Tutti", tools:"Strumenti", comment:"commento", uncomment:"Decommenta", marktext:"Mark Testo", removemark:"Rimuovere Mark", removeallmark:"Rimuovi tutto Mark", autoformat:"Formattazione automatica", configuration:"Configurazione", options:"Opzioni", help:"Aiuto",language:"lingua"};


var ja_ID = { file:"Berkas", new:"Anyar", open:"Mbukak", save:"Nyimpen", import:"Ngimpor", export:"Kaca", print:"Nyithak", exit:"Metu", edit:"Sunting", undo:"Batalaken", redo:"Mbaleni", copy:"Salinan", cut:"Motong", paste:"", search:"Telusuri", find:"Golek", findnext:"Golek Sabanjure", findprev:"Golek Sakdurungé", replace:"ngganti", replaceall:"ngganti Kabeh", view:"Pirsani", markline:"tandha Jalur", deleteline:"mbusak Jalur", newline:"baris anyar", inserttab:"Pasang Tab", fold:"melu", unfold:"mbukak", foldall:"melu Kabeh", unfoldall:"mbukak Kabeh", tools:"Kolom", comment:"smještaj", uncomment:"Uncomment", marktext:"Mark Wewacan", removemark:"mbusak Mark", removeallmark:"Mbusak Kabeh Mark", autoformat:"Auto Format", configuration:"Konfiguras", options:"Opsi", help:"Bantuan",language:"Basa"};

var ja_JP = { file:"ファイル", new:"新しいです", open:"オープン", save:"セーブ", import:"インポート", export:"エクスポート", print:"プリント", exit:"出口", edit:"編集", undo:"取り消します", redo:"やり直します", copy:"コピー", cut:"カット", paste:"ペースト", search:"検索", find:"見つけます", findnext:"次を検索", findprev:"前のページを探します", replace:"交換します", replaceall:"すべて置換", view:"見ます", markline:"マークライン", deleteline:"行を削除します", newline:"新しい行", inserttab:"挿入タブ", fold:"フォールド", unfold:"展開します", foldall:"すべて折りたたみ", unfoldall:"すべてを展開", tools:"ツール", comment:"コメント", uncomment:"コメントを解除", marktext:"マークテキスト", removemark:"マークを削除します", removeallmark:"すべてのマークを削除します", autoformat:"自動フォーマット", configuration:"コンフィギュレーション", options:"オプション", help:"助けて",language:"言語"};

var ko_KR = { file:"파일", new:"새로운", open:"열린", save:"저장", import:"수입", export:"수출", print:"인쇄", exit:"출구", edit:"편집", undo:"취소", redo:"다시 실행", copy:"복사", cut:"절단", paste:"풀", search:"수색", find:"발견", findnext:"다음 찾기", findprev:"이전 찾기", replace:"교체", replaceall:"모두 바꾸기", view:"전망", markline:"마크 라인", deleteline:"줄을 삭제", newline:"뉴 라인", inserttab:"삽입 탭", fold:"겹", unfold:"펴다", foldall:"모든 접어", unfoldall:"모두 펼쳐", tools:"도구", comment:"논평", uncomment:"주석을 해제", marktext:"마크 텍스트", removemark:"마크 제거", removeallmark:"모든 표시를 제거", autoformat:"자동 서식", configuration:"구성", options:"옵션", help:"도움",language:"언어"};



var ms_MY = { file:"Fail", new:"Baru", open:"Terbuka", save:"Menyelamatkan", import:"Mengimport", export:"Eksport", print:"Cetak", exit:"Keluar", edit:"Sunting", undo:"Membatalkan", redo:"Buat semula", copy:"Salinan", cut:"Potong", paste:"Pes", search:"Carian", find:"Cari", findnext:"Cari Seterusnya", findprev:"Cari Sebelumnya", replace:"Ganti", replaceall:"Ganti Semua", view:"Lihat", markline:"Mark Talian", deleteline:"Padam Talian", newline:"Line baru", inserttab:"Masukkan Tab", fold:"lipat", unfold:"Buka", foldall:"lipat Semua", unfoldall:"Buka Semua", tools:"Alat", comment:"Ulasan", uncomment:"tanda komentar", marktext:"tanda Text", removemark:"Buang Mark", removeallmark:"Buang Semua Mark", autoformat:"Auto Format", configuration:"Konfigurasi", options:"Pilihan", help:"Membantu",language:"bahasa"};

var nb_NO = { file:"Fil", new:"Ny", open:"Åpen", save:"Lagre", import:"Importere", export:"Eksporter", print:"Trykk", exit:"Utgang", edit:"Rediger", undo:"Angre", redo:"Gjenta", copy:"Kopi", cut:"Kutt", paste:"Lim", search:"Søk", find:"finne", findnext:"Finn Neste", findprev:"Finn Prev", replace:"Erstatt", replaceall:"Erstatt alle", view:"utsikt", markline:"Mark Linje", deleteline:"Slett Linje", newline:"ny linje", inserttab:"Sett Tab", fold:"Brett", unfold:"Brett ut", foldall:"Brett alle", unfoldall:"utfolde Alle", tools:"Verktøy", comment:"Comment", uncomment:"Uncomment", marktext:"Mark tekst", removemark:"Fjern Mark", removeallmark:"Fjern alt Mark", autoformat:"Auto Format", configuration:"Konfigurasjon", options:"Alternativer", help:"Hjelpe",language:"språk"};

var pl_PL = { file:"Plik", new:"Nowy", open:"Otwarte", save:"Zaoszczędzić", import:"Przywóz", export:"Eksportowy", print:"Drukować", exit:"Wyjście", edit:"Edytuj", undo:"Rozpiąć", redo:"Przerobić", copy:"Kopia", cut:"Cięcie", paste:"Ciasto", search:"poszukiwanie", find:"odnaleźć", findnext:"Znajdź następny", findprev:"Znajdź Poprzedni", replace:"zastąpić", replaceall:"Zamień wszystko", view:"widok", markline:"Mark Linia", deleteline:"Usuń linię", newline:"Nowa Linia", inserttab:"Wstaw Tab", fold:"zagiąć", unfold:"rozwijać się", foldall:"Zwiń wszystkie", unfoldall:"Rozwiń wszystkie", tools:"Narzędzia", comment:"komentarz", uncomment:"Usuń komentarz", marktext:"Mark Tekst", removemark:"Usuń Mark", removeallmark:"Usuń wszystkie Mark", autoformat:"Auto Format", configuration:"Konfiguracja", options:"Opcje", help:"Pomoc",language:"język"};


var pt_BA = { file:"Arquivo", new:"Novo", open:"Abrir", save:"Salvar", import:"Importar", export:"Exportar", print:"Imprimir", exit:"Sair", edit:"Editar", undo:"Desfazer", redo:"Refazer", copy:"Copiar", cut:"Cortar", paste:"Colar", search:"Procurar", find:"Buscar", findnext:"Buscar Próxima", findprev:"Buscar Anterior", replace:"Substituir", replaceall:"Substituir Tudo", view:"Vista", markline:"Marcar Linha", deleteline:"Deletar Linha", newline:"Nova Linha", inserttab:"Inserir Tab", fold:"Contrair", unfold:"Expandir", foldall:"Expandir Tudo", unfoldall:"Contrair Tudo", tools:"Ferramentas", comment:"Comentar", uncomment:"Descomentar", marktext:"Marcar Texto", removemark:"Remover Marcar", removeallmark:"Remover todas Marcas", autoformat:"Auto Formatação", configuration:"Configurações", options:"Opcões", help:"Ajuda",language:"Linguagem"};


var ro_RO = { file:"FiÈ™ier", new:"Nou", open:"Deschis", save:"Salva", import:"Importul", export:"Exportul", print:"Imprimare", exit:"Ieșire", edit:"Edita", undo:"Anula", redo:"Reface", copy:"Copie", cut:"Tăiat", paste:"Pastă", search:"căutare", find:"găsi", findnext:"Găsiți Urmatorul", findprev:"Găsiți Inainte", replace:"înlocui", replaceall:"Înlocuiește tot", view:"vedere", markline:"Marcu linie", deleteline:"Ștergeți linie", newline:"noua linie", inserttab:"Inserare Tab", fold:"plia", unfold:"desfășura", foldall:"fold Toate", unfoldall:"Desfaceți Toate", tools:"Instrumente", comment:"comentariu", uncomment:"decomentați", marktext:"Mark Textul", removemark:"Scoateți Mark", removeallmark:"Eliminați toate Mark", autoformat:"Auto Format", configuration:"Configurație", options:"Opțiuni", help:"Ajutor",language:"limbă"};


var ru_RU = { file:"новый", new:"новый", open:"открыто", save:"сохранять", import:"импорт", export:"экспорт", print:"печать", exit:"выход", edit:"редактировать", undo:"аннулировать", redo:"переделывать", copy:"копия", cut:"вырезать", paste:"паста", search:"поиск", find:"найти", findnext:"Найти Далее", findprev:"Найти Предыдущая", replace:"заменять", replaceall:"Заменить все", view:"вид", markline:"Отметить линия", deleteline:"Удалить линию", newline:"Новая Линия", inserttab:"Вставьте Tab", fold:"сложить", unfold:"раскрываться", foldall:"Свернуть всё", unfoldall:"Раскрыть все", tools:"инструменты", comment:"комментарий", uncomment:"Раскоментируйте", marktext:"Отметить Текст", removemark:"Удалить Отметить", removeallmark:"Удалить все Марка", autoformat:"Авто Формат", configuration:"конфигурация", options:"опции", help:"помогите",language:"язык"};


var sv_SE = { file:"Fil", new:"Ny", open:"öppen", save:"Spara", import:"Importen", export:"Exporten", print:"Trycket", exit:"Utgång", edit:"Redigera", undo:"ångra", redo:"Göra om", copy:"Kopia", cut:"Klippa", paste:"Klistra", search:"Sök", find:"hitta", findnext:"Sök nästa", findprev:"Hitta Föreg", replace:"Ersätt", replaceall:"Ersätt alla", view:"utsikt", markline:"Mark Linje", deleteline:"Radera rad", newline:"Ny rad", inserttab:"Infoga Tab", fold:"Vik", unfold:"Vik", foldall:"Vik alla", unfoldall:"Vik alla", tools:"Verktyg", comment:"Kommentar", uncomment:"avkommentera", marktext:"Markera text", removemark:"Ta bort Mark", removeallmark:"Ta bort alla Mark", autoformat:"Auto Format", configuration:"Konfiguration", options:"Alternativ", help:"Hjälpa",language:"språk"};


var tr_TR = { file:"Dosya", new:"Yeni", open:"Açık", save:"Kurtarmak", import:"Ithalat", export:"Ihracat", print:"Baskı", exit:"Çıkmak", edit:"Düzenlemek", undo:"Geri", redo:"Yeniden yapmak", copy:"Kopya", cut:"Kesim", paste:"Macun", search:"arama", find:"bulmak", findnext:"Sonrakini Bul", findprev:"Önceki bul", replace:"değiştirmek", replaceall:"Tümünü Değiştir", view:"görünüm", markline:"Mark Hattı", deleteline:"Hattı Sil", newline:"yeni satır", inserttab:"Ekle Sekmesi", fold:"kat", unfold:"açılmak", foldall:"Hepsi Fold", unfoldall:"Tümünü Çıkar", tools:"Araçlar", comment:"açıklama", uncomment:"Uncomment", marktext:"Mark Metin", removemark:"Mark Çıkar", removeallmark:"Tüm Mark kaldır", autoformat:"Otomatik Format", configuration:"Yapılandırma", options:"Seçenekleri", help:"Yardım",language:"lisan"};

var uk_UA = { file:"файл", new:"новий", open:"відкрито", save:"зберігати", import:"імпорт", export:"експорт", print:"друк", exit:"вихід", edit:"редагувати", undo:"анулювати", redo:"переробляти", copy:"копія", cut:"вирізати", paste:"паста", search:"Пошук", find:"знайти", findnext:"знайти Далі", findprev:"знайти Попередня", replace:"замінювати", replaceall:"замінити всі", view:"вид", markline:"відзначити лінія", deleteline:"видалити лінію", newline:"Нова Лінія", inserttab:"вставте Tab", fold:"скласти", unfold:"розкриватися", foldall:"Згорнути все", unfoldall:"розкрити всі", tools:"інструменти", comment:"коментар", uncomment:"раськоментіруйте", marktext:"відзначити Текст", removemark:"видалити", removeallmark:"Видалити все Марка", autoformat:"авто Формат", configuration:"конфігурація", options:"опції", help:"Допоможіть",language:"Мова"};


var zh_TW = { file:"文件", new:"新", open:"開放", save:"節省", import:"進口", export:"出口", print:"打印", exit:"離開", edit:"編輯", undo:"復原", redo:"翻拍", copy:"複製", cut:"切", paste:"項鍊", search:"搜索", find:"发现", findnext:"查找下一个", findprev:"查找上一个", replace:"更换", replaceall:"全部替换", view:"视图", markline:"马克线", deleteline:"删除线", newline:"新线", inserttab:"插入标签", fold:"折", unfold:"展开", foldall:"全部折叠", unfoldall:"全部展开", tools:"工具", comment:"评论", uncomment:"取消注释", marktext:"马克文本", removemark:"删除标记", removeallmark:"删除所有标记", autoformat:"自动套用格式", configuration:"組態", options:"選項", help:"救命",language:"语言"};


arrayLanguages["af_ZA"] = af_ZA;
arrayLanguages["ar_AA"] = ar_AA;
arrayLanguages["cs_CZ"] = cs_CZ;
arrayLanguages["da_DA"] = da_DA;
arrayLanguages["de_DE"] = de_DE;
arrayLanguages["el_GR"] = el_GR;
arrayLanguages["es_ES"] = es_ES;
arrayLanguages["en_US"] = en_US;
arrayLanguages["fa_IR"] = fa_IR;
arrayLanguages["fr_FR"] = fr_FR;
arrayLanguages["he_IL"] = he_IL;
arrayLanguages["hi_IN"] = hi_IN;
arrayLanguages["hr_HR"] = hr_HR;
arrayLanguages["hu_HU"] = hu_HU;
arrayLanguages["id_ID"] = id_ID;
arrayLanguages["it_IT"] = it_IT;
arrayLanguages["ja_ID"] = ja_ID;
arrayLanguages["ja_JP"] = ja_JP;
arrayLanguages["ko_KR"] = ko_KR;
arrayLanguages["ms_MY"] = ms_MY;
arrayLanguages["nb_NO"] = nb_NO;
arrayLanguages["pl_PL"] = pl_PL;
arrayLanguages["pt_BA"] = pt_BA;
arrayLanguages["ro_RO"] = ro_RO;
arrayLanguages["ru_RU"] = ru_RU;
arrayLanguages["sv_SE"] = sv_SE;
arrayLanguages["tr_TR"] = tr_TR;
arrayLanguages["uk_UA"] = uk_UA;
arrayLanguages["zh_TW"] = zh_TW;





















