<?php


$language =array();
$language['system']['file'] = 'Arquivo';
$language['system']['new'] = 'Novo';
$language['system']['open'] = 'Abrir';
$language['system']['save'] = 'Salvar';
$language['system']['import'] = 'Importar';
$language['system']['export'] = 'Exportar';
$language['system']['print'] = 'Imprimir';
$language['system']['exit'] = 'Sair';
$language['system']['edit'] = 'Editar';
$language['system']['undo'] = 'Desfazer';
$language['system']['redo'] = 'Refazer';
$language['system']['copy'] = 'Copiar';
$language['system']['cut'] = 'Cortar';
$language['system']['paste'] = 'Color';
$language['system']['search'] = 'Procurar';
$language['system']['find'] = 'Buscar';
$language['system']['findnext'] = 'Buscar Próxima';
$language['system']['findprev'] = 'Buscar Anterior';
$language['system']['replace'] = 'Substituir';
$language['system']['replaceall'] = 'Substituir Tudo';
$language['system']['view'] = 'Vista';
$language['system']['markline'] = 'Marcar Linha';
$language['system']['deleteline'] = 'Deletar Linha';
$language['system']['newline'] = 'Nova Linha';
$language['system']['inserttab'] = 'Inserir Tab';
$language['system']['fold'] = 'Contrair';
$language['system']['unfold'] = 'Expandir';
$language['system']['foldall'] = 'Expandir Tudo';
$language['system']['unfoldall'] = 'Contrair Tudo';
$language['system']['tools'] = 'Ferramentas';
$language['system']['comment'] = 'Comentar';
$language['system']['uncomment'] = 'Descomentar';
$language['system']['marktext'] = 'Marcar Texto';
$language['system']['removemark'] = 'Remover Marcar';
$language['system']['removeallmark'] = 'Remover todas Marcas';
$language['system']['autoformat'] = 'Auto Formatação';
$language['system']['configuration'] = 'Configuração';
$language['system']['options'] = 'Opcões';
$language['system']['help'] = 'Ajuda';

$language['system']['control_panel'] = 'Painel de Controle';
$language['system']['adjust_settings_computer'] = 'Ajustar as configurações do computador';
$language['system']['security'] = 'Segurança';
$language['system']['folder_options'] = 'Opções de pasta';
$language['system']['backup'] = 'backup';
$language['system']['programs'] = 'Programas';
$language['system']['user_account'] = 'Conta de Usuário';
$language['system']['Appearance'] = 'Aparência';
$language['system']['start_menu'] = 'Menu Inicial';
$language['system']['system'] = 'Sistema';
$language['system']['languages'] = 'Idiomas';
$language['system']['fonts'] = 'Fontes';
$language['system']['date'] = 'Data';
$language['system']['configure_backup'] = 'Configure Backup';
$language['system']['select_location_store'] = 'Selecionar o Local para Armazenar';
$language['system']['user'] = 'Usuario';
$language['system']['create'] = 'Criar';
$language['system']['new_local'] = 'Novo Local';
$language['system']['remove'] = 'Remover';
$language['system']['next'] = 'Próximo';
$language['system']['cancel'] = 'Cancelar';
$language['system']['program_list'] = 'Lista de Programas';
$language['system']['install'] = 'Instalar';
$language['system']['store'] = 'Loja';
$language['system']['name'] = 'Nome';
$language['system']['group'] = 'Grupo';
$language['system']['user_account_settings'] = 'Configuração de Conta de Usuário';
$language['system']['user_group_account_settings'] = 'Configuração de Grupo de Conta de Usuário';
$language['system']['new_user'] = 'Novo Usuário';
$language['system']['reset'] = 'Resetar';
$language['system']['new_group'] = 'Novo Grupo';
$language['system']['parent_group'] = 'Grupo Pai';
$language['system']['add_user_title'] = 'Use a lista abaixo para conceder ou negar acesso aos usuários do computador e redefinir senhas.';
//Use the list below to grant or deny users access to the computer and reset passwords.
$language['system']['permission'] = 'Permissão';
$language['system']['permission_group'] = 'Grupo de Permissão';
$language['system']['update_available'] = 'Atualizações importantes estão disponíveis';
$language['system']['optional_available'] = 'Atualizações opcionais estão disponíveis';
$language['system']['system_information'] = 'Informação do sistema';
$language['system']['operation_system'] = 'Sistema Operacional';
$language['system']['version'] = 'Versão';
$language['system']['memory_usage'] = 'uso de memória';
$language['system']['peak_memory_usage'] = 'Uso de memória de pico';
$language['system']['browser_name'] = 'Nome do navegador';
$language['system']['plataform'] = 'Plataforma';
$language['system']['system_languages'] = 'Linguagem do sistema';
$language['system']['title_language_system'] = 'Usar para mudar o idioma do sistema.';
$language['system']['new_font'] = 'Nova Fonte';
$language['system']['path'] = 'Caminho';
$language['system']['time'] = 'Hora';
$language['system']['change_date'] = 'Mudar data';
$language['system']['change_timezone'] = 'Mudar fuso horário';
$language['system']['title_change_date'] = 'Definir a data e horário';
$language['system']['time_zone'] = 'Fuso horário';
$language['system']['current_date_hours'] = 'Date e horas correntes';
$language['system']['desktop'] = 'Area de Trabalho';
$language['system']['library'] = 'Biblioteca';
$language['system']['documents'] = 'Documentos';
$language['system']['images'] = 'Imagens';
$language['system']['musics'] = 'Musicas';
$language['system']['videos'] = 'Videos';
$language['system']['login_settings'] = 'Configuração de Login';
$language['system']['login_type'] = 'Tipo de Login';
$language['system']['login_encrypt'] = 'Criptografia de Login';
$language['system']['number_bits'] = 'Número de Bits';
$language['system']['number_attemps'] = 'Número de tentativas';
$language['system']['password_force'] = 'Força da senha';
$language['system']['enable_security_question'] = 'Habilitar pergunta de segurança';
$language['system']['enable_capctha'] = 'Habilitar capctha';
$language['system']['capctha_type'] = 'Tipo de capctha';
$language['system']['change'] = 'Mudar';
$language['system']['poor'] = 'Fraca';
$language['system']['good'] = 'Boa';
$language['system']['excellent'] = 'Excelente';
$language['system']['search'] = 'Procurar';
$language['system']['custom_settings'] = 'Configurações personalizadas';
$language['system']['change_theme'] = 'Mudar Tema';
$language['system']['change_account_image'] = 'Mudar Imagem da Conta';
$language['system']['change_mouse_icon'] = 'Mudar Icone do Mouse';
$language['system']['theme_settings'] = 'Configurações de Tema';
$language['system']['create_theme_folder'] = 'Criar pasta do tema';
$language['system']['add_theme_from_wos'] = 'Adicionat tema do WOS';
$language['system']['upload_from_computer'] = 'Upload do computador';
$language['system']['set'] = 'Definir';
$language['system']['title_install'] = 'Bem-vindo ao assistente de instalação do programa';
$language['system']['description_install'] = 'the installation wizard will help you to modify, repair, and remove the program.';
$language['system']['extract'] = 'Extrair';



$language['system']['ok']= 'ok';
$language['system']['Email']= "Email";
$language['system']['login']= "login"; 
$language['system']['password']= "password";
$language['system']['choose_mouse']= "Escolha ícone do mouse para a sua conta";
$language['system']['chouse_mouse_description']= "O ícone do mouse escolhida aparecerá na tela";
$language['system']['search_wos']= "Procurar em  WOS";
$language['system']['change_image']= "Alterar imagem";
$language['system']['upload_from_your_co´puter']= "Carregar a partir do seu computador";
$language['system']['choose_new_picture']= "Escolha uma nova imagem para a conta";
$language['system']['choose_new_picture_description']= "A imagem escolhida será exibido na tela de login";
$language['system']['repeat']= "repetir";
$language['system']['title_user_list']= "Use a lista abaixo para conceder ou negar os usuários grupos de acesso ao computador.";
$language['system']['user_this_wos']= "Grupo de usuários deste Wos";
$language['system']['back']= "Voltar";
$language['system']['user_descriotion']= "Use a lista abaixo para conceder ou negar aos usuários acesso a programas no computado";
$language['system']['allowed_group']= "Grupos autorizados";
$language['system']['users_dnied']= "usuários negados";
$language['system']['programs_permission']= "Permissão de Programas";
$language['system']['deny_users']= "negar Usuários";
$language['system']['new_password']= "Nova senha";
$language['system']['confirm_passowrd']= "Confirme a Senha";
$language['system']['captcha']= "Captcha";
$language['system']['set_time_zone']= "Definir o fuso horário";
$language['system']['reset_password']= "Resetar senha";
$language['system']['change_passwod_title']= "Para alterar a senha, clique em Redefinir Senha";
$language['system']['compress']= "comprimir";
$language['system']['back_restore']= "Backup ou restaurar seus arquivos";
$language['system']['w0s_edition']= "Edição WOS";
$language['system']['system']= "Sistema";
$language['system']['browser_information']= "Informações do navegador";
$language['system']['my_computer']= "meu computador";
$language['system']['select_zip_file']= "Selecione a entrada Zip arquivo para instalar o programa";









?>