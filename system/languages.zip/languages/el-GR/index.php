<?php

/*-----------------greek------------------*/
$language =array();
$language['htmleditor']['file'] = 'αρχείο';
$language['htmleditor']['new'] = 'νέος';
$language['htmleditor']['open'] = 'Aνοιχτό';
$language['htmleditor']['save'] = 'εκτός';
$language['htmleditor']['import'] = 'εισαγωγή';
$language['htmleditor']['export'] = 'εξαγωγή';
$language['htmleditor']['print'] = 'Εκτύπωση';
$language['htmleditor']['exit'] = 'έξοδος';

$language['htmleditor']['edit'] = 'Επεξεργασία';
$language['htmleditor']['undo'] = 'αναίρεση';
$language['htmleditor']['redo'] = 'ξανακάνω';
$language['htmleditor']['copy'] = 'αντίγραφο';
$language['htmleditor']['cut'] = 'κόψιμο';
$language['htmleditor']['paste'] = 'πάστα';

$language['htmleditor']['search'] = 'έρευνα';
$language['htmleditor']['find'] = 'βρίσκω';
$language['htmleditor']['findnext'] = 'βρείτε Επόμενο';
$language['htmleditor']['findprev'] = 'βρείτε Προηγούμενο';
$language['htmleditor']['replace'] = 'Αντικαταστήστε';
$language['htmleditor']['replaceall'] = 'Αντικατάσταση όλων';

$language['htmleditor']['view'] = 'θέα';
$language['htmleditor']['markline'] = 'ισάλου γραμμής';
$language['htmleditor']['deleteline'] = 'Διαγραφή γραμμής';
$language['htmleditor']['newline'] = 'νέας Γραμμής';
$language['htmleditor']['inserttab'] = 'Εισαγωγή Tab';
$language['htmleditor']['fold'] = 'πτυχή';
$language['htmleditor']['unfold'] = 'Ξεδιπλώστε';
$language['htmleditor']['foldall'] = 'Διπλώστε Όλα';
$language['htmleditor']['unfoldall'] = 'Ξεδιπλώστε Όλα';

$language['htmleditor']['tools'] = 'εργαλεία';
$language['htmleditor']['comment'] = 'σχόλιο';
$language['htmleditor']['uncomment'] = 'αποσχολιάσετε';
$language['htmleditor']['marktext'] = 'Mark Κείμενο';
$language['htmleditor']['removemark'] = 'Κατάργηση Mark';
$language['htmleditor']['removeallmark'] = 'Κατάργηση όλων Mark';
$language['htmleditor']['autoformat'] = 'Αυτόματο φορμά';
$language['htmleditor']['configuration'] = 'διαμόρφωση';
$language['htmleditor']['options'] = 'Επιλογές';

$language['htmleditor']['help'] = 'βοήθεια';




$language['system']['control_panel'] = 'Πίνακας Ελέγχου';
$language['system']['adjust_settings_computer'] = 'Προσαρμόστε τις ρυθμίσεις του υπολογιστή';
$language['system']['security'] = 'ασφάλεια';
$language['system']['folder_options'] = 'επιλογές φακέλου';
$language['system']['backup'] = 'εφεδρικός';
$language['system']['programs'] = 'προγράμματα';
$language['system']['user_account'] = 'λογαριασμός χρήστη';
$language['system']['appearance'] = 'εμφάνιση';
$language['system']['start_menu'] = 'αρχικο ΜΕΝΟΥ';
$language['system']['system'] = 'σύστημα';
$language['system']['languages'] = 'γλώσσες';
$language['system']['fonts'] = 'γραμματοσειρές';
$language['system']['date'] = 'ημερομηνία';
$language['system']['configure_backup'] = 'Διαμορφώστε αντιγράφων ασφαλείας';
$language['system']['select_location_store'] = 'Επιλέξτε την τοποθεσία για την αποθήκευση.';
$language['system']['user'] = 'μεταχειριζόμενος';
$language['system']['create'] = 'δημιουργώ';
$language['system']['new_local'] = 'νέων τοπικών';
$language['system']['remove'] = 'αφαιρώ';
$language['system']['next'] = 'επόμενος';
$language['system']['cancel'] = 'ματαίωση';
$language['system']['program_list'] = 'κατάλογος των προγραμμάτων';
$language['system']['install'] = 'εγκαθιστώ';
$language['system']['store'] = 'κατάστημα';
$language['system']['name'] = 'όνομα';
$language['system']['group'] = 'ομάδα';
$language['system']['user_account_settings'] = 'ρυθμίσεις του λογαριασμού χρήστη';
$language['system']['user_group_account_settings'] = 'Ρυθμίσεις λογαριασμού ομάδα χρηστών';
$language['system']['new_user'] = 'νέος χρήστης';
$language['system']['reset'] = 'επαναφορά';
$language['system']['new_group'] = 'νέα ομάδα';
$language['system']['parent_group'] = 'ομάδα γονέων';
$language['system']['add_user_title'] = 'Χρησιμοποιήστε την παρακάτω λίστα για να χορηγήσει ή να αρνηθεί στους χρήστες πρόσβαση στον υπολογιστή και να επαναφέρετε τους κωδικούς πρόσβασης..';
$language['system']['permission'] = 'άδεια';
$language['system']['permission_group'] = 'ομάδα άδεια';
$language['system']['update_available'] = 'σημαντικές ενημερώσεις είναι διαθέσιμες';
$language['system']['optional_available'] = 'προαιρετικές ενημερώσεις είναι διαθέσιμες';
$language['system']['system_information'] = 'πληροφορίες συστήματος';
$language['system']['operation_system'] = 'σύστημα λειτουργίας';
$language['system']['version'] = 'εκδοχή';
$language['system']['memory_usage'] = 'χρήση μνήμης';
$language['system']['peak_memory_usage'] = 'μέγιστη χρήση μνήμης';
$language['system']['browser_name'] = 'όνομα του προγράμματος περιήγησης';
$language['system']['plataform'] = 'plataform';
$language['system']['system_languages'] = 'γλώσσες του συστήματος';
$language['system']['title_language_system'] = 'Χρησιμοποιήστε το για να αλλάξετε τη γλώσσα του συστήματος..';
$language['system']['new_font'] = 'νέα γραμματοσειρά';
$language['system']['path'] = 'μονοπάτι';
$language['system']['time'] = 'χρόνος';
$language['system']['change_date'] = 'ημερομηνία αλλαγής';
$language['system']['change_timezone'] = 'την αλλαγή της ζώνης ώρας';
$language['system']['title_change_date'] = 'Ρυθμίστε την ημερομηνία και το χρονοδιάγραμμα';
$language['system']['time_zone'] = 'ζώνη ώρας';
$language['system']['current_date_hours'] = 'Τρέχουσες ημερομηνίες και ώρες';
$language['system']['desktop'] = 'επιφάνεια εργασίας';
$language['system']['library'] = 'βιβλιοθήκη';
$language['system']['documents'] = 'έγγραφα';
$language['system']['images'] = 'εικόνες';
$language['system']['musics'] = 'μουσικές';
$language['system']['videos'] = 'βίντεο';
$language['system']['login_settings'] = 'ρυθμίσεις σύνδεσης';
$language['system']['login_type'] = 'σύνδεσης τύπου';
$language['system']['login_encrypt'] = 'login κρυπτογραφημένα';
$language['system']['number_bits'] = 'αριθμός των bits';
$language['system']['number_attemps'] = 'αριθμό προσπαθειών';
$language['system']['password_force'] = 'ισχύος κωδικού πρόσβασης';
$language['system']['enable_security_question'] = 'επιτρέπουν ερώτηση ασφαλείας';
$language['system']['enable_capctha'] = 'επιτρέπουν captcha';
$language['system']['capctha_type'] = 'τύπος captcha';
$language['system']['change'] = 'αλλαγή';
$language['system']['poor'] = 'φτωχός';
$language['system']['good'] = 'καλός';
$language['system']['excellent'] = 'έξοχος';
$language['system']['search'] = 'έρευνα';
$language['system']['custom_settings'] = 'προσαρμοσμένες ρυθμίσεις';
$language['system']['change_theme'] = 'το θέμα της αλλαγής του';
$language['system']['change_account_image'] = 'αλλαγή του λογαριασμού εικόνα';
$language['system']['change_mouse_icon'] = 'εικονίδιο αλλαγής του ποντικιού';
$language['system']['theme_settings'] = 'ρυθμίσεις θέματος';
$language['system']['create_theme_folder'] = 'δημιουργία φακέλου θέμα';
$language['system']['add_theme_from_wos'] = 'Προσθήκη θέματος από WOS';
$language['system']['upload_from_computer'] = 'ανεβάσετε από τον υπολογιστή';
$language['system']['set'] = 'σειρά';
$language['system']['title_install'] = 'Καλώς ήλθατε στον οδηγό εγκατάστασης προγραμμάτων';
$language['system']['description_install'] = 'ο οδηγός εγκατάστασης θα σας βοηθήσει να τροποποιήσετε, επισκευή, και να καταργήσετε το πρόγραμμα.';
$language['system']['extract'] = 'εκχύλισμα';



$language['system']['ok']= 'Εντάξει';
$language['system']['Email']= "E-mail";
$language['system']['login']= "Σύνδεση"; 
$language['system']['password']= "σύνθημα";
$language['system']['choose_mouse']= "Επιλέξτε το εικονίδιο του ποντικιού για το λογαριασμό σας";
$language['system']['chouse_mouse_description']= "Το επιλεγμένο εικονίδιο του ποντικιού θα εμφανιστεί στην οθόνη";
$language['system']['search_wos']= "Αναζήτηση WOS";
$language['system']['change_image']= "αλλαγή εικόνας";
$language['system']['upload_from_your_co´puter']= "Μεταφόρτωση από τον υπολογιστή σας";
$language['system']['choose_new_picture']= "Επιλέξτε μια νέα εικόνα για το λογαριασμό σας";
$language['system']['choose_new_picture_description']= "Η επιλεγμένη εικόνα θα εμφανιστεί στην οθόνη σύνδεσης";
$language['system']['repeat']= "επαναλαμβάνω";
$language['system']['title_user_list']= "Χρησιμοποιήστε την παρακάτω λίστα για να χορηγήσει ή να αρνηθεί στους χρήστες ομάδες, η πρόσβαση στον υπολογιστή.";
$language['system']['user_this_wos']= "Ομάδα χρήστη Αυτή ήταν";
$language['system']['back']= "Πίσω";
$language['system']['user_descriotion']= "Χρησιμοποιήστε την παρακάτω λίστα για να χορηγήσει ή να αρνηθεί στους χρήστες πρόσβαση σε προγράμματα στον υπολογιστή.";
$language['system']['allowed_group']= "επιτρέπονται Ομάδες";
$language['system']['users_dnied']= "χρήστες Denied";
$language['system']['programs_permission']= "προγράμματα άδεια";
$language['system']['deny_users']= "αρνούνται χρήστες";
$language['system']['new_password']= "Νέος Κωδικός";
$language['system']['confirm_passowrd']= "Επιβεβαίωση κωδικού";
$language['system']['captcha']= "Captcha";
$language['system']['set_time_zone']= "Ρύθμιση ζώνης ώρας";
$language['system']['reset_password']= "Επαναφέρετε τον κωδικό πρόσβασης";
$language['system']['change_passwod_title']= "Για να αλλάξετε τον κωδικό πρόσβασης, κάντε κλικ στην επιλογή Επαναφορά κωδικού πρόσβασης";
$language['system']['compress']= "συμπιέζω";
$language['system']['back_restore']= "Back up or restore your files";
$language['system']['w0s_edition']= "Wos Edition";
$language['system']['system']= "Σύστημα";
$language['system']['browser_information']= "Πληροφορίες προγράμματος περιήγησης";
$language['system']['my_computer']= "Ο υπολογιστής μου";
$language['system']['select_zip_file']= "Επιλέξτε εισόδου Zip αρχείο για να εγκαταστήσετε το πρόγραμμα";

?>
