<?php

/*---------------HEBREW -------------*/
$language =array();
$language['htmleditor']['file'] = 'קובץ';
$language['htmleditor']['new'] = 'חדש';
$language['htmleditor']['open'] = 'פתוח';
$language['htmleditor']['save'] = 'להציל';
$language['htmleditor']['import'] = 'יבוא';
$language['htmleditor']['export'] = 'יצוא';
$language['htmleditor']['print'] = 'הדפסה';
$language['htmleditor']['exit'] = 'יציאה';

$language['htmleditor']['edit'] = 'עריכה';
$language['htmleditor']['undo'] = 'לבטל';
$language['htmleditor']['redo'] = 'שוב';
$language['htmleditor']['copy'] = 'עותק';
$language['htmleditor']['cut'] = 'לחתוך';
$language['htmleditor']['paste'] = 'דבק';

$language['htmleditor']['search'] = 'חיפוש';
$language['htmleditor']['find'] = 'מצא';
$language['htmleditor']['findnext'] = 'חפש את הבא';
$language['htmleditor']['findprev'] = 'מצא קודם';
$language['htmleditor']['replace'] = 'החלף';
$language['htmleditor']['replaceall'] = 'החלף הכל';

$language['htmleditor']['view'] = 'צפה ב';
$language['htmleditor']['markline'] = 'מארק קו';
$language['htmleditor']['deleteline'] = 'מחיקת קו';
$language['htmleditor']['newline'] = 'קו חדש';
$language['htmleditor']['inserttab'] = 'הכנס Tab';
$language['htmleditor']['fold'] = 'מקפלים';
$language['htmleditor']['unfold'] = 'לפתוח';
$language['htmleditor']['foldall'] = 'מקפלים כל';
$language['htmleditor']['unfoldall'] = 'לפתוח כל';

$language['htmleditor']['tools'] = 'כלים';
$language['htmleditor']['comment'] = 'תגובה';
$language['htmleditor']['uncomment'] = 'בטלהערה';
$language['htmleditor']['marktext'] = 'מארק טקסט';
$language['htmleditor']['removemark'] = 'הסר מארק';
$language['htmleditor']['removeallmark'] = 'הסר את כל מרק';
$language['htmleditor']['autoformat'] = 'פורמט אוטומטי';
$language['htmleditor']['configuration'] = 'תצורה';
$language['htmleditor']['options'] = 'אפשרויות';

$language['htmleditor']['help'] = 'לעזור';




$language['system']['control_panel'] = 'לוח בקרה';
$language['system']['adjust_settings_computer'] = 'התאם את הגדרות של המחשב';
$language['system']['security'] = 'בִּטָחוֹן';
$language['system']['folder_options'] = 'אפשרויות תיקייה';
$language['system']['backup'] = 'גיבוי';
$language['system']['programs'] = 'תוכניות';
$language['system']['user_account'] = 'חשבון משתמש';
$language['system']['appearance'] = 'מראה חיצוני';
$language['system']['start_menu'] = 'תפריט התחל';
$language['system']['system'] = 'מַעֲרֶכֶת';
$language['system']['languages'] = 'בשפות';
$language['system']['fonts'] = 'גופנים';
$language['system']['date'] = 'תַאֲרִיך';
$language['system']['configure_backup'] = 'גדר גיבוי';
$language['system']['select_location_store'] = 'בחר את המיקום לאחסון.';
$language['system']['user'] = 'מִשׁתַמֵשׁ';
$language['system']['create'] = 'לִיצוֹר';
$language['system']['new_local'] = 'חדשות מקומיות';
$language['system']['remove'] = 'לְהַסִיר';
$language['system']['next'] = 'הַבָּא';
$language['system']['cancel'] = ' ְבַטֵל';
$language['system']['program_list'] = 'ברשימת תוכניות';
$language['system']['install'] = 'לְהַתְקִין';
$language['system']['store'] = 'חֲנוּת';
$language['system']['name'] = 'שֵׁם';
$language['system']['group'] = 'קְבוּצָה';
$language['system']['user_account_settings'] = 'הגדרות חשבון משתמש';
$language['system']['user_group_account_settings'] = 'קבוצת משתמשי הגדרות חשבון';
$language['system']['new_user'] = 'משתמש חדש';
$language['system']['reset'] = 'אִתחוּל';
$language['system']['new_group'] = 'קבוצה חדשה';
$language['system']['parent_group'] = 'קבוצת ההורה';
$language['system']['add_user_title'] = 'השתמש ברשימה הבאה כדי להעניק או לשלול למשתמשים גישה למחשב לאפס סיסמאות.';
$language['system']['permission'] = 'רְשׁוּת';
$language['system']['permission_group'] = 'קבוצת הרשאות';
$language['system']['update_available'] = 'עדכונים חשובים זמינים';
$language['system']['optional_available'] = 'עדכונים אופציונליים זמינים';
$language['system']['system_information'] = 'מידע מערכת';
$language['system']['operation_system'] = 'מערכת הפעלה';
$language['system']['version'] = 'גִרְסָה';
$language['system']['memory_usage'] = 'שימוש בזיכרון';
$language['system']['peak_memory_usage'] = 'שימוש בזיכרון שיא';
$language['system']['browser_name'] = 'שם הדפדפן';
$language['system']['plataform'] = 'פּלַטפוֹרמָה';
$language['system']['system_languages'] = 'בשפות המערכת';
$language['system']['title_language_system'] = 'השתמש כדי לשנות את שפת המערכת.';
$language['system']['new_font'] = 'גופן חדש';
$language['system']['path'] = 'נָתִיב';
$language['system']['time'] = 'זְמַן';
$language['system']['change_date'] = 'התאריך והשעה של שינוי';
$language['system']['change_timezone'] = 'אזור זמן לשינוי';
$language['system']['title_change_date'] = 'הגדר את התאריך בלוח זמנים';
$language['system']['time_zone'] = 'אזור זמן';
$language['system']['current_date_hours'] = 'תאריכים ושעות נוכחיים';
$language['system']['desktop'] = 'שולחן העבודה';
$language['system']['library'] = 'סִפְרִיָה';
$language['system']['documents'] = 'מסמכים';
$language['system']['images'] = 'תמונות';
$language['system']['musics'] = 'musics';
$language['system']['videos'] = 'קטעי וידאו';
$language['system']['login_settings'] = 'הגדרות התחברות';
$language['system']['login_type'] = 'סוג התחברות';
$language['system']['login_encrypt'] = 'התחבר מוצפן';
$language['system']['number_bits'] = 'מספר סיבי';
$language['system']['number_attemps'] = 'ניסיונות מספר';
$language['system']['password_force'] = 'כוח הסיסמה';
$language['system']['enable_security_question'] = 'לאפשר שאלת אבטחה';
$language['system']['enable_capctha'] = 'לאפשר captcha';
$language['system']['capctha_type'] = 'סוג captcha';
$language['system']['change'] = 'כסף קטן';
$language['system']['poor'] = 'עני';
$language['system']['good'] = 'טוֹב';
$language['system']['excellent'] = 'מְעוּלֶה';
$language['system']['search'] = 'לְחַפֵּשׂ';
$language['system']['custom_settings'] = 'הגדרות מותאמות אישית';
$language['system']['change_theme'] = 'נושא שינוי';
$language['system']['change_account_image'] = 'תמונת חשבון שינוי';
$language['system']['change_mouse_icon'] = 'סמל עכבר השינוי';
$language['system']['theme_settings'] = 'הגדרות נושא';
$language['system']['create_theme_folder'] = 'ליצור תיקיה נושא';
$language['system']['add_theme_from_wos'] = 'להוסיף נושא מתוך WOS';
$language['system']['upload_from_computer'] = 'להעלות מהמחשב';
$language['system']['set'] = 'מַעֲרֶכֶת';
$language['system']['title_install'] = 'ברוכים הבאים אל אשף התקנת תוכניות';
$language['system']['description_install'] = 'אשף ההתקנה יסייע לך לשנות, לתקן ולהסיר את התוכנית.';
$language['system']['extract'] = 'לְהוֹצִיא';




$language['system']['ok']= 'בסדר';
$language['system']['Email']= "אֶלֶקטרוֹנִי";
$language['system']['login']= "התחבר"; 
$language['system']['password']= "סִיסמָה";
$language['system']['choose_mouse']= "בחר עכבר סמל עבור חשבונך";
$language['system']['chouse_mouse_description']= "סמל העכבר הנבחר יופיע על המסך";
$language['system']['search_wos']= "חיפוש ב WOS";
$language['system']['change_image']= "שינוי תמונה";
$language['system']['upload_from_your_co´puter']= "העלה מהמחשב שלך";
$language['system']['choose_new_picture']= "בחר תמונה חדשה לחשבונך";
$language['system']['choose_new_picture_description']= "הדימוי הנבחר יופיע על מסך הכניסה";
$language['system']['repeat']= "חזור";
$language['system']['title_user_list']= "השתמש ברשימה הבאה כדי להעניק או לשלול משתמשים קבוצות לגשת למחשב..";
$language['system']['user_this_wos']= "קבוצה למשתמש זה Wos";
$language['system']['back']= "חזור";
$language['system']['user_descriotion']= "השתמש ברשימה הבאה כדי להעניק או לשלול למשתמשים גישה לתוכניות במחשב.";
$language['system']['allowed_group']= "קבוצות מורשות";
$language['system']['users_dnied']= "משתמשים שנדחו";
$language['system']['programs_permission']= "הרשאת תוכניות";
$language['system']['deny_users']= "מונעים ממשתמשים";
$language['system']['new_password']= "סיסמה חדשה";
$language['system']['confirm_passowrd']= "אשר סיסמא";
$language['system']['captcha']= "Captcha";
$language['system']['set_time_zone']= "הגדרת אזור זמן";
$language['system']['reset_password']= "לאפס את הסיסמה";
$language['system']['change_passwod_title']= "כדי לשנות את הסיסמה, לחץ איפוס סיסמה";
$language['system']['compress']= "לִדחוֹס";
$language['system']['back_restore']= "לגבות או לשחזר את הקבצים שלך";
$language['system']['w0s_edition']= "מהדורת WOS";
$language['system']['system']= "מַעֲרֶכֶת";
$language['system']['browser_information']= "מידע דפדפן";
$language['system']['my_computer']= "המחשב שלי";
$language['system']['select_zip_file']= "קלט קובץ zip בחר התקן את התוכנית";
?>
