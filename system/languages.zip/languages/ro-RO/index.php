<?php

/*-------------------Romanian----------------*/
$language =array();
$language['htmleditor']['file'] = 'Fișier';
$language['htmleditor']['new'] = 'Nou';
$language['htmleditor']['open'] = 'Deschis';
$language['htmleditor']['save'] = 'Salva';
$language['htmleditor']['import'] = 'Importul';
$language['htmleditor']['export'] = 'Exportul';
$language['htmleditor']['print'] = 'Imprimare';
$language['htmleditor']['exit'] = 'Ieșire';

$language['htmleditor']['edit'] = 'Edita';
$language['htmleditor']['undo'] = 'Anula';
$language['htmleditor']['redo'] = 'Reface';
$language['htmleditor']['copy'] = 'Copie';
$language['htmleditor']['cut'] = 'Tăiat';
$language['htmleditor']['paste'] = 'Pastă';

$language['htmleditor']['search'] = 'căutare';
$language['htmleditor']['find'] = 'găsi';
$language['htmleditor']['findnext'] = 'Găsiți Urmatorul';
$language['htmleditor']['findprev'] = 'Găsiți Inainte';
$language['htmleditor']['replace'] = 'înlocui';
$language['htmleditor']['replaceall'] = 'Înlocuiește tot';

$language['htmleditor']['view'] = 'vedere';
$language['htmleditor']['markline'] = 'Marcu linie';
$language['htmleditor']['deleteline'] = 'Ștergeți linie';
$language['htmleditor']['newline'] = 'noua linie';
$language['htmleditor']['inserttab'] = 'Inserare Tab';
$language['htmleditor']['fold'] = 'plia';
$language['htmleditor']['unfold'] = 'desfășura';
$language['htmleditor']['foldall'] = 'fold Toate';
$language['htmleditor']['unfoldall'] = 'Desfaceți Toate';

$language['htmleditor']['tools'] = 'Instrumente';
$language['htmleditor']['comment'] = 'comentariu';
$language['htmleditor']['uncomment'] = 'decomentați';
$language['htmleditor']['marktext'] = 'Mark Textul';
$language['htmleditor']['removemark'] = 'Scoateți Mark';
$language['htmleditor']['removeallmark'] = 'Eliminați toate Mark';
$language['htmleditor']['autoformat'] = 'Auto Format';
$language['htmleditor']['configuration'] = 'Configurație';
$language['htmleditor']['options'] = 'Opțiuni';

$language['htmleditor']['help'] = 'Ajutor';




$language['system']['control_panel'] = 'Panoul de control';
$language['system']['adjust_settings_computer'] = 'Imbunătăți setările calculatorului';
$language['system']['security'] = 'securitate';
$language['system']['folder_options'] = 'opţiuni folder';
$language['system']['backup'] = 'copie de rezervă';
$language['system']['programs'] = 'programe';
$language['system']['user_account'] = 'cont de utilizator';
$language['system']['appearance'] = 'apariție';
$language['system']['start_menu'] = 'meniul start';
$language['system']['system'] = 'sistem';
$language['system']['languages'] = 'limbi';
$language['system']['fonts'] = 'fonturi';
$language['system']['date'] = 'data';
$language['system']['configure_backup'] = 'configurați Backup';
$language['system']['select_location_store'] = 'Selectați locația pentru a stoca.';
$language['system']['user'] = 'utilizator';
$language['system']['create'] = 'crea';
$language['system']['new_local'] = 'locale nou';
$language['system']['remove'] = 'elimina';
$language['system']['next'] = 'următor';
$language['system']['cancel'] = 'anula';
$language['system']['program_list'] = 'liste de programe';
$language['system']['install'] = 'instalare';
$language['system']['store'] = 'magazin';
$language['system']['name'] = 'Nume';
$language['system']['group'] = 'grup';
$language['system']['user_account_settings'] = 'Setările contului de utilizator';
$language['system']['user_group_account_settings'] = 'Setările contului de grup de utilizatori';
$language['system']['new_user'] = 'utilizator nou';
$language['system']['reset'] = 'restabili';
$language['system']['new_group'] = 'grup nou';
$language['system']['parent_group'] = 'grup părinte';
$language['system']['add_user_title'] = 'Utilizați lista de mai jos pentru a acorda sau refuza accesul utilizatorilor la computer și resetarea parolelor.';
$language['system']['permission'] = 'permisiune';
$language['system']['permission_group'] = 'grup de permisiune';
$language['system']['update_available'] = 'actualizări importante sunt disponibile';
$language['system']['optional_available'] = 'actualizări opționale sunt disponibile';
$language['system']['system_information'] = 'informatii despre sistem';
$language['system']['operation_system'] = 'sistem de operare';
$language['system']['version'] = 'versiune';
$language['system']['memory_usage'] = 'folosirea memoriei';
$language['system']['peak_memory_usage'] = 'utilizarea memoriei de vârf';
$language['system']['browser_name'] = 'nume de browser';
$language['system']['plataform'] = 'platformă';
$language['system']['system_languages'] = 'limbi de sistem';
$language['system']['title_language_system'] = 'Utilizați pentru a schimba limba sistemului.';
$language['system']['new_font'] = 'font nou';
$language['system']['path'] = 'cale';
$language['system']['time'] = 'timp';
$language['system']['change_date'] = 'schimba data';
$language['system']['change_timezone'] = 'schimbare de fus orar';
$language['system']['title_change_date'] = 'Setați data și programul';
$language['system']['time_zone'] = 'fus orar';
$language['system']['current_date_hours'] = 'datele și orele curente';
$language['system']['desktop'] = 'desktop-ul';
$language['system']['library'] = 'bibliotecă';
$language['system']['documents'] = 'documente';
$language['system']['images'] = 'imagini';
$language['system']['musics'] = 'muzici';
$language['system']['videos'] = 'Videoclipuri';
$language['system']['login_settings'] = 'setările de conectare';
$language['system']['login_type'] = 'tip conectare';
$language['system']['login_encrypt'] = 'criptați autentificare';
$language['system']['number_bits'] = 'numărul de biți';
$language['system']['number_attemps'] = 'încercări numerice';
$language['system']['password_force'] = 'vigoare parola';
$language['system']['enable_security_question'] = 'activați întrebarea de securitate';
$language['system']['enable_capctha'] = 'activați captcha';
$language['system']['capctha_type'] = 'tip captcha';
$language['system']['change'] = 'Schimbare';
$language['system']['poor'] = 'sărac';
$language['system']['good'] = 'bun';
$language['system']['excellent'] = 'excellent';
$language['system']['search'] = 'căutare';
$language['system']['custom_settings'] = 'setari personalizate';
$language['system']['change_theme'] = 'schimbă tema';
$language['system']['change_account_image'] = 'image cont schimbare';
$language['system']['change_mouse_icon'] = 'icon schimbare mouse-ului';
$language['system']['theme_settings'] = 'setările tematice';
$language['system']['create_theme_folder'] = 'crea un dosar temă';
$language['system']['add_theme_from_wos'] = 'adăugați temă din WOS';
$language['system']['upload_from_computer'] = 'încărcați de pe computer';
$language['system']['set'] = 'a stabilit';
$language['system']['title_install'] = 'Bun venit la expertul de instalare de programe';
$language['system']['description_install'] = 'asistentul de instalare vă va ajuta să modificați, să repare și să eliminați programul.';
$language['system']['extract'] = 'extrage';



$language['system']['ok']= 'ok';
$language['system']['Email']= "E-mail";
$language['system']['login']= "Logare"; 
$language['system']['password']= "parola";
$language['system']['choose_mouse']= "Alege pictograma mouse-ul pentru contul dvs.";
$language['system']['chouse_mouse_description']= "Pictograma mouse-ului ales va apărea pe ecran";
$language['system']['search_wos']= "Căutare în WOS";
$language['system']['change_image']= "schimbare de imagine";
$language['system']['upload_from_your_co´puter']= "Încărcați de pe computer";
$language['system']['choose_new_picture']= "Alegeți o nouă imagine pentru contul dv";
$language['system']['choose_new_picture_description']= "Imaginea aleasă va apărea pe ecranul de conectare";
$language['system']['repeat']= "repeta";
$language['system']['title_user_list']= "Utilizați lista de mai jos pentru a acorda sau refuza utilizatorilor grupuri de acces la calculator.";
$language['system']['user_this_wos']= "Utilizator Group acest Wos";
$language['system']['back']= "Înapoi";
$language['system']['user_descriotion']= "Utilizați lista de mai jos pentru a acorda sau refuza utilizatorilor accesul la programe în calculator.";
$language['system']['allowed_group']= "Grupuri permise";
$language['system']['users_dnied']= "utilizatorii Denied";
$language['system']['programs_permission']= "programe permisiune";
$language['system']['deny_users']= "Refuzați Utilizatori";
$language['system']['new_password']= "Parolă Nouă";
$language['system']['confirm_passowrd']= "confirma parola";
$language['system']['captcha']= "Captcha";
$language['system']['set_time_zone']= "Setați fusul orar";
$language['system']['reset_password']= "Reseteaza parola";
$language['system']['change_passwod_title']= "Pentru a schimba parola, faceți clic pe Resetare parolă";
$language['system']['compress']= "comprima";
$language['system']['back_restore']= "Copie de rezervă sau de a restaura fișierele";
$language['system']['w0s_edition']= "Wos Edition";
$language['system']['system']= "Sistem";
$language['system']['browser_information']= "Informații browser";
$language['system']['my_computer']= "Calculatorul meu";
$language['system']['select_zip_file']= "Selectați Fișier Zip de intrare pentru a instala programul";


?>
