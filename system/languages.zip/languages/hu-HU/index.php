<?php
/*---------------Hungarian---------------*/

$language =array();
$language['htmleditor']['file'] = 'Akta';
$language['htmleditor']['new'] = 'Új';
$language['htmleditor']['open'] = 'Nyitva';
$language['htmleditor']['save'] = 'Megment';
$language['htmleditor']['import'] = 'Behozatali';
$language['htmleditor']['export'] = 'Kiviteli';
$language['htmleditor']['print'] = 'Nyomtatás';
$language['htmleditor']['exit'] = 'Kijárat';

$language['htmleditor']['edit'] = 'Szerkesztés';
$language['htmleditor']['undo'] = 'Kibont';
$language['htmleditor']['redo'] = 'Újra';
$language['htmleditor']['copy'] = 'Másolat';
$language['htmleditor']['cut'] = 'Vágott';
$language['htmleditor']['paste'] = 'Paszta';

$language['htmleditor']['search'] = 'keresés';
$language['htmleditor']['find'] = 'talál';
$language['htmleditor']['findnext'] = 'Következő keresése';
$language['htmleditor']['findprev'] = 'Keresse Előző';
$language['htmleditor']['replace'] = 'Cserélje';
$language['htmleditor']['replaceall'] = 'Az összes cseréje';

$language['htmleditor']['view'] = 'kilátás';
$language['htmleditor']['markline'] = 'jelzésre';
$language['htmleditor']['deleteline'] = 'sor törlése';
$language['htmleditor']['newline'] = 'új vonal';
$language['htmleditor']['inserttab'] = 'Helyezze Tab';
$language['htmleditor']['fold'] = 'Hajtsa';
$language['htmleditor']['unfold'] = 'kibontakozik';
$language['htmleditor']['foldall'] = 'Hajtsa Összes';
$language['htmleditor']['unfoldall'] = 'Hajtsuk ki minden';

$language['htmleditor']['tools'] = 'Szerszámok';
$language['htmleditor']['comment'] = 'megjegyzés';
$language['htmleditor']['uncomment'] = 'megjegyzésből';
$language['htmleditor']['marktext'] = 'Mark szöveg';
$language['htmleditor']['removemark'] = 'Távolítsuk el Mark';
$language['htmleditor']['removeallmark'] = 'Minden eltávolítása Mark';
$language['htmleditor']['autoformat'] = 'Auto Format';
$language['htmleditor']['configuration'] = 'Konfiguráció';
$language['htmleditor']['options'] = 'Opciók';

$language['htmleditor']['help'] = 'Segít';



$language['system']['control_panel'] = 'Kezelőpanel';
$language['system']['adjust_settings_computer'] = 'A beállítások módosítása a számítógép';
$language['system']['security'] = 'biztonság';
$language['system']['folder_options'] = 'mappabeállítások';
$language['system']['backup'] = 'biztonsági mentés';
$language['system']['programs'] = 'programok';
$language['system']['user_account'] = 'Felhasználói fiók';
$language['system']['appearance'] = 'kinézet';
$language['system']['start_menu'] = 'start menu';
$language['system']['system'] = 'rendszer';
$language['system']['languages'] = 'nyelvek';
$language['system']['fonts'] = 'betűtípusok';
$language['system']['date'] = 'dátum';
$language['system']['configure_backup'] = 'Állítsa Backup';
$language['system']['select_location_store'] = 'Válassza helyen tárolni.';
$language['system']['user'] = 'használó';
$language['system']['create'] = 'teremt';
$language['system']['new_local'] = 'új helyi';
$language['system']['remove'] = 'eltávolít';
$language['system']['next'] = 'következő';
$language['system']['cancel'] = 'törölni';
$language['system']['program_list'] = 'programok listáját';
$language['system']['install'] = 'felszerel';
$language['system']['store'] = 'bolt';
$language['system']['name'] = 'név';
$language['system']['group'] = 'csoport';
$language['system']['user_account_settings'] = 'felhasználói fiók beállításai';
$language['system']['user_group_account_settings'] = 'felhasználói csoport fiók beállításai';
$language['system']['new_user'] = 'új felhasználó';
$language['system']['reset'] = 'vissza';
$language['system']['new_group'] = 'új csoport';
$language['system']['parent_group'] = 'szülőcsoporttal';
$language['system']['add_user_title'] = 'Az alábbi listából, hogy megadja vagy megtagadja a felhasználók hozzáférést a számítógéphez, és a jelszavak törlésére.';
$language['system']['permission'] = 'engedély';
$language['system']['permission_group'] = 'engedélycsoport';
$language['system']['update_available'] = 'Fontos frissítések érhetők';
$language['system']['optional_available'] = 'opcionális frissítések érhetők';
$language['system']['system_information'] = 'rendszer információ';
$language['system']['operation_system'] = 'operációs rendszer';
$language['system']['version'] = 'változat';
$language['system']['memory_usage'] = 'memóriahasználat';
$language['system']['peak_memory_usage'] = 'csúcs memória használat';
$language['system']['browser_name'] = 'böngésző neve';
$language['system']['plataform'] = 'emelvény';
$language['system']['system_languages'] = 'rendszernyelveknek';
$language['system']['title_language_system'] = 'Használatával módosíthatja a rendszer nyelve.';
$language['system']['new_font'] = 'új betűtípus';
$language['system']['path'] = 'pálya';
$language['system']['time'] = 'idő';
$language['system']['change_date'] = 'dátum módosítása';
$language['system']['change_timezone'] = 'Időzóna';
$language['system']['title_change_date'] = 'Állítsa be a dátumot és a menetrend';
$language['system']['time_zone'] = 'időzóna';
$language['system']['current_date_hours'] = 'Aktuális dátum és időpont';
$language['system']['desktop'] = 'asztali';
$language['system']['library'] = 'könyvtár';
$language['system']['documents'] = 'dokumentumok';
$language['system']['images'] = 'képek';
$language['system']['musics'] = 'zenék';
$language['system']['videos'] = 'videók';
$language['system']['login_settings'] = 'bejelentkezési beállítások';
$language['system']['login_type'] = 'bejelentkezés típusa';
$language['system']['login_encrypt'] = 'login titkosított';
$language['system']['number_bits'] = 'bitek száma';
$language['system']['number_attemps'] = 'számú próbálkozás';
$language['system']['password_force'] = 'jelszó erő';
$language['system']['enable_security_question'] = ' engedélyezze a biztonsági kérdés';
$language['system']['enable_capctha'] = 'lehetővé captcha';
$language['system']['capctha_type'] = 'captcha típus';
$language['system']['change'] = 'változás';
$language['system']['poor'] = 'szegény';
$language['system']['good'] = 'jó';
$language['system']['excellent'] = 'kiváló';
$language['system']['search'] = ' keres';
$language['system']['custom_settings'] = 'egyéni beállítások';
$language['system']['change_theme'] = 'változás téma';
$language['system']['change_account_image'] = 'változás fiók kép';
$language['system']['change_mouse_icon'] = 'változás az egér ikonra';
$language['system']['theme_settings'] = 'sablon beállításait';
$language['system']['create_theme_folder'] = 'hozzon létre mappát téma';
$language['system']['add_theme_from_wos'] = 'add témát WOS';
$language['system']['upload_from_computer'] = 'feltölteni a számítógépről';
$language['system']['set'] = 'készlet';
$language['system']['title_install'] = 'Üdvözöljük a programok telepítő varázsló';
$language['system']['description_install'] = 'A telepítő varázsló segít módosítására, javítására, és távolítsa el a programot..';
$language['system']['extract'] = 'kivonat';



$language['system']['ok']= 'rendben';
$language['system']['Email']= "Email";
$language['system']['login']= "bejelentkezés"; 
$language['system']['password']= "jelszó";
$language['system']['choose_mouse']= "Válasszon egér ikon fiókja";
$language['system']['chouse_mouse_description']= "A kiválasztott egér ikon jelenik meg a képernyőn";
$language['system']['search_wos']= "Keresés az WOS";
$language['system']['change_image']= "kép módosítása";
$language['system']['upload_from_your_co´puter']= "Feltöltése a számítógépről";
$language['system']['choose_new_picture']= "Válasszon egy új képet a fiókja";
$language['system']['choose_new_picture_description']= "A kiválasztott kép megjelenik a bejelentkező képernyő";
$language['system']['repeat']= "ismétlés";
$language['system']['title_user_list']= "Az alábbi listából, hogy megadja vagy megtagadja a felhasználói csoportok hozzáférést a számítógéphez..";
$language['system']['user_this_wos']= "User Group ezt Wos";
$language['system']['back']= "Hát";
$language['system']['user_descriotion']= "Az alábbi listából, hogy megadja vagy megtagadja a felhasználók programokhoz való hozzáférést a számítógép.";
$language['system']['allowed_group']= "Engedélyezett csoportok";
$language['system']['users_dnied']= "felhasználók megtagadva";
$language['system']['programs_permission']= "programok Engedély";
$language['system']['deny_users']= "Deny felhasználók";
$language['system']['new_password']= "új jelszó";
$language['system']['confirm_passowrd']= "jelszó megerősítése";
$language['system']['captcha']= "Captcha";
$language['system']['set_time_zone']= "Állítsa be az időzónát";
$language['system']['reset_password']= "Jelszó visszaállítása";
$language['system']['change_passwod_title']= "A jelszó megváltoztatásához, kattintson a Reset Password";
$language['system']['compress']= "borogatás";
$language['system']['back_restore']= "Mentés vagy visszaállítási fájlok";
$language['system']['w0s_edition']= "Wos Edition";
$language['system']['system']= "Rendszer";
$language['system']['browser_information']= "böngésző információ";
$language['system']['my_computer']= "A számítógépem";
$language['system']['select_zip_file']= "Select Zip File input a program telepítése";


?>
