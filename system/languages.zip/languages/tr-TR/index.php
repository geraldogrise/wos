<?php

/*-------------Turkish --------------*/
$language =array();
$language['htmleditor']['file'] = 'Dosya';
$language['htmleditor']['new'] = 'Yeni';
$language['htmleditor']['open'] = 'Açık';
$language['htmleditor']['save'] = 'Kurtarmak';
$language['htmleditor']['import'] = 'Ithalat';
$language['htmleditor']['export'] = 'Ihracat';
$language['htmleditor']['print'] = 'Baskı';
$language['htmleditor']['exit'] = 'Çıkmak';

$language['htmleditor']['edit'] = 'Düzenlemek';
$language['htmleditor']['undo'] = 'Geri';
$language['htmleditor']['redo'] = 'Yeniden yapmak';
$language['htmleditor']['copy'] = 'Kopya';
$language['htmleditor']['cut'] = 'Kesim';
$language['htmleditor']['paste'] = 'Macun';

$language['htmleditor']['search'] = 'arama';
$language['htmleditor']['find'] = 'bulmak';
$language['htmleditor']['findnext'] = 'Sonrakini Bul';
$language['htmleditor']['findprev'] = 'Önceki bul';
$language['htmleditor']['replace'] = 'değiştirmek';
$language['htmleditor']['replaceall'] = 'Tümünü Değiştir';

$language['htmleditor']['view'] = 'görünüm';
$language['htmleditor']['markline'] = 'Mark Hattı';
$language['htmleditor']['deleteline'] = 'Hattı Sil';
$language['htmleditor']['newline'] = 'yeni satır';
$language['htmleditor']['inserttab'] = 'Ekle Sekmesi';
$language['htmleditor']['fold'] = 'kat';
$language['htmleditor']['unfold'] = 'açılmak';
$language['htmleditor']['foldall'] = 'Hepsi Fold';
$language['htmleditor']['unfoldall'] = 'Tümünü Çıkar';

$language['htmleditor']['tools'] = 'Araçlar';
$language['htmleditor']['comment'] = 'açıklama';
$language['htmleditor']['uncomment'] = 'Uncomment';
$language['htmleditor']['marktext'] = 'Mark Metin';
$language['htmleditor']['removemark'] = 'Mark kaldır';
$language['htmleditor']['removeallmark'] = 'Tüm Mark kaldır';
$language['htmleditor']['autoformat'] = 'Otomatik Format';
$language['htmleditor']['configuration'] = 'Yapılandırma';
$language['htmleditor']['options'] = 'Seçenekleri';

$language['htmleditor']['help'] = 'Yardım';




$language['system']['control_panel'] = 'Kontrol Paneli';
$language['system']['adjust_settings_computer'] = 'Bilgisayar Ayarlarını Yapma';
$language['system']['security'] = 'güvenlik';
$language['system']['folder_options'] = 'dosya seçenekleri';
$language['system']['backup'] = 'yedek';
$language['system']['programs'] = 'programlar';
$language['system']['user_account'] = 'kullanıcı hesabı';
$language['system']['appearance'] = 'görünüm';
$language['system']['start_menu'] = 'başlangıç menüsü';
$language['system']['system'] = 'sistem';
$language['system']['languages'] = 'dil';
$language['system']['fonts'] = 'fontlar';
$language['system']['date'] = 'tarih';
$language['system']['configure_backup'] = 'Yedekleme yapılandırma';
$language['system']['select_location_store'] = 'saklamak için bir konum seçin.';
$language['system']['user'] = 'kullanıcı';
$language['system']['create'] = 'oluşturmak';
$language['system']['new_local'] = 'yerel yeni';
$language['system']['remove'] = 'Kaldır';
$language['system']['next'] = 'Sonraki';
$language['system']['cancel'] = ' iptal';
$language['system']['program_list'] = 'programlar listesinde';
$language['system']['install'] = 'kurmak';
$language['system']['store'] = 'mağaza';
$language['system']['name'] = 'isim';
$language['system']['group'] = 'grup';
$language['system']['user_account_settings'] = 'kullanıcı hesabı ayarları';
$language['system']['user_group_account_settings'] = 'kullanıcı grubu hesabı ayarları';
$language['system']['new_user'] = 'yeni kullanıcı';
$language['system']['reset'] = 'reset';
$language['system']['new_group'] = 'yeni Grup';
$language['system']['parent_group'] = 'üst grup';
$language['system']['add_user_title'] = 'vermek veya bilgisayara kullanıcıların erişimini engellemek ve şifreleri sıfırlamak için aşağıdaki listeyi kullanın.';
$language['system']['permission'] = 'izin';
$language['system']['permission_group'] = 'izin grubu';
$language['system']['update_available'] = 'Önemli güncelleştirmeler kullanılabilir';
$language['system']['optional_available'] = 'isteğe bağlı güncelleştirmeler mevcut';
$language['system']['system_information'] = 'sistem bilgisi';
$language['system']['operation_system'] = 'işletim sistemi';
$language['system']['version'] = 'versiyon';
$language['system']['memory_usage'] = 'hafıza kullanımı';
$language['system']['peak_memory_usage'] = 'tepe bellek kullanımı';
$language['system']['browser_name'] = 'tarayıcı adı';
$language['system']['plataform'] = 'platform';
$language['system']['system_languages'] = 'sistem dilleri';
$language['system']['title_language_system'] = 'Sistem dilini değiştirmek için kullanın.';
$language['system']['new_font'] = 'yeni yazı';
$language['system']['path'] = 'yol';
$language['system']['time'] = 'zaman';
$language['system']['change_date'] = 'tarihi değiştir';
$language['system']['change_timezone'] = 'değişiklik saat dilimi';
$language['system']['title_change_date'] = 'Tarih ve zamanlamasını ayarlamak';
$language['system']['time_zone'] = 'saat dilimi';
$language['system']['current_date_hours'] = 'Güncel tarih ve saat';
$language['system']['desktop'] = 'masaüstü';
$language['system']['library'] = 'kütüphane';
$language['system']['documents'] = 'evraklar';
$language['system']['images'] = 'görüntüleri';
$language['system']['musics'] = 'müzikler';
$language['system']['videos'] = 'videolar';
$language['system']['login_settings'] = 'giriş ayarları';
$language['system']['login_type'] = 'bağlantı türü';
$language['system']['login_encrypt'] = 'giriş şifrelemek';
$language['system']['number_bits'] = 'bit sayısı';
$language['system']['number_attemps'] = 'sayı girişimleri';
$language['system']['password_force'] = 'şifre gücü';
$language['system']['enable_security_question'] = 'Güvenlik sorunuzu etkinleştirme';
$language['system']['enable_capctha'] = 'captcha\'yı etkinleştirme';
$language['system']['capctha_type'] = 'kaptan tipi';
$language['system']['change'] = 'değişim';
$language['system']['poor'] = 'yoksul';
$language['system']['good'] = 'iyi';
$language['system']['excellent'] = ' mükemmel';
$language['system']['search'] = 'arama';
$language['system']['custom_settings'] = 'özel ayarlar';
$language['system']['change_theme'] = 'temayı değiştir';
$language['system']['change_account_image'] = 'değişim hesabı görüntü';
$language['system']['change_mouse_icon'] = 'değişiklik fare simgesi';
$language['system']['theme_settings'] = 'tema ayarları';
$language['system']['create_theme_folder'] = 'Tema klasörü oluşturmak';
$language['system']['add_theme_from_wos'] = 'WOS dan tema ekleme';
$language['system']['upload_from_computer'] = 'bilgisayardan yüklemek';
$language['system']['set'] = 'set';
$language['system']['title_install'] = 'programlar kurulum sihirbazı hoş geldiniz';
$language['system']['description_install'] = 'kurulum sihirbazı, onarım değiştirmek için yardımcı olacak ve programı kaldırmak olacaktır.';
$language['system']['extract'] = 'özüt';


$language['system']['ok']= 'ok';
$language['system']['Email']= "E-posta";
$language['system']['login']= "oturum aç"; 
$language['system']['password']= "parola";
$language['system']['choose_mouse']= "Hesabınız için fare simgesini seçin";
$language['system']['chouse_mouse_description']= "seçilen fare simgesi ekranda belirecektir";
$language['system']['search_wos']= "WOS ara";
$language['system']['change_image']= "Resmi değiştir";
$language['system']['upload_from_your_co´puter']= "Bilgisayarınızdan yükleyin";
$language['system']['choose_new_picture']= "Hesabınız için yeni bir resim seçin";
$language['system']['choose_new_picture_description']= "seçilen görüntü giriş ekranında görünecektir";
$language['system']['repeat']= "tekrar";
$language['system']['title_user_list']= "gruplar bilgisayara erişen kullanıcıları vermek veya reddetmek için aşağıdaki listeyi kullanın.";
$language['system']['user_this_wos']= "Kullanıcı Grubu bu Wos";
$language['system']['back']= "Geri";
$language['system']['user_descriotion']= "hibe veya kullanıcılara bilgisayar programlarına erişimini engellemek için aşağıdaki listeyi kullanın.";
$language['system']['allowed_group']= "İzin Grupları";
$language['system']['users_dnied']= "Kullanıcılar Reddedildiı";
$language['system']['programs_permission']= "KProgramlar İzin";
$language['system']['deny_users']= "kullanıcıları Reddet";
$language['system']['new_password']= "Yeni Şifre";
$language['system']['confirm_passowrd']= "Şifreyi Onayla";
$language['system']['captcha']= "Captcha";
$language['system']['set_time_zone']= "Set zaman dilimi";
$language['system']['reset_password']= "Şifreyi yenile";
$language['system']['change_passwod_title']= "parolasını değiştirmek için, Parolayı Sıfırla tıklayın";
$language['system']['compress']= "kompres";
$language['system']['back_restore']= "Yedekleme veya dosyalarınızı geri";
$language['system']['w0s_edition']= "Wos Sürümü";
$language['system']['system']= "sistem";
$language['system']['browser_information']= "tarayıcı Bilgileri";
$language['system']['my_computer']= "Benim bilgisayarım";
$language['system']['select_zip_file']= "programı yükleyin için seçin Zip Dosyası girişi";


?>
