<?php

/*--------------------jav------------------*/
$language =array();
$language['htmleditor']['file'] = 'Berkas';
$language['htmleditor']['new'] = 'Anyar';
$language['htmleditor']['open'] = 'Mbukak';
$language['htmleditor']['save'] = 'Nyimpen';
$language['htmleditor']['import'] = 'Ngimpor';
$language['htmleditor']['export'] = 'Kaca';
$language['htmleditor']['print'] = 'Nyithak';
$language['htmleditor']['exit'] = 'Metu';

$language['htmleditor']['edit'] = 'Sunting';
$language['htmleditor']['undo'] = 'Batalaken';
$language['htmleditor']['redo'] = 'Mbaleni';
$language['htmleditor']['copy'] = 'Salinan';
$language['htmleditor']['cut'] = 'Motong';
$language['htmleditor']['paste'] = 'ペースト';

$language['htmleditor']['search'] = 'Telusuri';
$language['htmleditor']['find'] = 'Golek';
$language['htmleditor']['findnext'] = 'Golek Sabanjure';
$language['htmleditor']['findprev'] = 'Golek Sakdurungé';
$language['htmleditor']['replace'] = 'ngganti';
$language['htmleditor']['replaceall'] = 'ngganti Kabeh';

$language['htmleditor']['view'] = 'Pirsani';
$language['htmleditor']['markline'] = 'tandha Jalur';
$language['htmleditor']['deleteline'] = 'mbusak Jalur';
$language['htmleditor']['newline'] = 'baris anyar';
$language['htmleditor']['inserttab'] = 'Pasang Tab';
$language['htmleditor']['fold'] = 'melu';
$language['htmleditor']['unfold'] = 'mbukak';
$language['htmleditor']['foldall'] = 'melu Kabeh';
$language['htmleditor']['unfoldall'] = 'mbukak Kabeh';

$language['htmleditor']['tools'] = 'Kolom';
$language['htmleditor']['comment'] = 'smještaj';
$language['htmleditor']['uncomment'] = 'Uncomment';
$language['htmleditor']['marktext'] = 'Mark Wewacan';
$language['htmleditor']['removemark'] = 'mbusak Mark';
$language['htmleditor']['removeallmark'] = 'Mbusak Kabeh Mark';
$language['htmleditor']['autoformat'] = 'Auto Format';
$language['htmleditor']['configuration'] = 'Konfiguras';
$language['htmleditor']['options'] = 'Opsi';

$language['htmleditor']['help'] = 'Bantuan';




$language['system']['control_panel'] = 'Control Panel';
$language['system']['adjust_settings_computer'] = 'Nyetel setelan saka komputer ing';
$language['system']['security'] = 'keamanan';
$language['system']['folder_options'] = 'opsi folder';
$language['system']['backup'] = 'serep';
$language['system']['programs'] = 'program';
$language['system']['user_account'] = 'panganggo';
$language['system']['appearance'] = 'katon';
$language['system']['start_menu'] = 'miwiti menu';
$language['system']['system'] = 'sistem';
$language['system']['languages'] = 'basa';
$language['system']['fonts'] = 'fonts';
$language['system']['date'] = 'tanggal';
$language['system']['configure_backup'] = 'ngatur Gawe serep';
$language['system']['select_location_store'] = 'Pilih lokasi kanggo nyimpen.';
$language['system']['user'] = 'panganggo';
$language['system']['create'] = 'nggawe';
$language['system']['new_local'] = 'anyar lokal';
$language['system']['remove'] = 'mbusak';
$language['system']['next'] = 'sabanjuré';
$language['system']['cancel'] = 'mbatalake';
$language['system']['program_list'] = 'dhaftar program';
$language['system']['install'] = 'nginstal';
$language['system']['store'] = 'nyimpen';
$language['system']['name'] = 'jeneng';
$language['system']['group'] = 'grup';
$language['system']['user_account_settings'] = 'setelan akun panganggo';
$language['system']['user_group_account_settings'] = 'setelan akun grup panganggo';
$language['system']['new_user'] = 'panganggo anyar';
$language['system']['reset'] = 'ngreset';
$language['system']['new_group'] = 'klompok anyar';
$language['system']['parent_group'] = 'grup sepah';
$language['system']['add_user_title'] = 'Gunakake dhaftar ngisor iki kanggo ngawèhaké utawa lali akses panganggo kanggo komputer lan pulihake sandhi.';
$language['system']['permission'] = 'ijin';
$language['system']['permission_group'] = ' ijin grup';
$language['system']['update_available'] = 'nganyari penting kasedhiya';
$language['system']['optional_available'] = 'nganyari pilihan sing kasedhiya';
$language['system']['system_information'] = 'sistem informasi';
$language['system']['operation_system'] = 'sistem operasi';
$language['system']['version'] = 'versi';
$language['system']['memory_usage'] = 'memori panggunaan';
$language['system']['peak_memory_usage'] = 'memori panggunaan puncak';
$language['system']['browser_name'] = 'jeneng browser name';
$language['system']['plataform'] = 'plataform';
$language['system']['system_languages'] = 'basa sistem';
$language['system']['title_language_system'] = 'Gunakake kanggo ngganti sistem basa.';
$language['system']['new_font'] = 'font anyar';
$language['system']['path'] = 'path';
$language['system']['time'] = 'wektu';
$language['system']['change_date'] = 'tanggal';
$language['system']['change_timezone'] = 'pangowahan  zona wektu';
$language['system']['title_change_date'] = 'Setel tanggal lan jadwal';
$language['system']['time_zone'] = ' zona wektu';
$language['system']['current_date_hours'] = 'Tanggal Saiki lan jam';
$language['system']['desktop'] = 'desktop';
$language['system']['library'] = 'perpustakaan';
$language['system']['documents'] = ' dokumen';
$language['system']['images'] = 'images';
$language['system']['musics'] = 'musics';
$language['system']['videos'] = 'video';
$language['system']['login_settings'] = 'setelan mlebu';
$language['system']['login_type'] = 'jinis mlebu';
$language['system']['login_encrypt'] = 'mlebu encrypt ';
$language['system']['number_bits'] = 'nomer bit';
$language['system']['number_attemps'] = 'nomer usaha';
$language['system']['password_force'] = 'sandi pasukan';
$language['system']['enable_security_question'] = 'ngaktifake pitakon keamanan';
$language['system']['enable_capctha'] = 'ngaktifake captcha';
$language['system']['capctha_type'] = 'jinis captcha';
$language['system']['change'] = 'owah-owahan';
$language['system']['poor'] = 'miskin';
$language['system']['good'] = 'apik';
$language['system']['excellent'] = 'banget';
$language['system']['search'] = 'panelusuran';
$language['system']['custom_settings'] = 'setelan adat';
$language['system']['change_theme'] = 'owah-owahan tema';
$language['system']['change_account_image'] = 'akun image pangowahan';
$language['system']['change_mouse_icon'] = 'lambang pangowahan mouse';
$language['system']['theme_settings'] = 'setelan tema';
$language['system']['create_theme_folder'] = 'nggawe folder tema';
$language['system']['add_theme_from_wos'] = 'nambah tema saka WOS';
$language['system']['upload_from_computer'] = 'ngunggah saka komputer';
$language['system']['set'] = 'pesawat';
$language['system']['title_install'] = 'Welcome to tuntunan program instalasi';
$language['system']['description_install'] = 'tuntunan instalasi bakal mbantu kanggo ngowahi, ndandani, lan mbusak program.';
$language['system']['extract'] = 'extract';



$language['system']['ok']= 'ok';
$language['system']['Email']= "Email";
$language['system']['login']= "mlebu"; 
$language['system']['password']= "sandi";
$language['system']['choose_mouse']= "Pilih lambang mouse kanggo akun";
$language['system']['chouse_mouse_description']= "lambang mouse milih bakal katon ing layar";
$language['system']['search_wos']= "Search in WOS";
$language['system']['change_image']= "Ganti Image";
$language['system']['upload_from_your_co´puter']= "Upload saka Komputer";
$language['system']['choose_new_picture']= "Pilih Gambar anyar kanggo akun";
$language['system']['choose_new_picture_description']= "gambar milih bakal katon ing layar login";
$language['system']['repeat']= "baleni";
$language['system']['title_user_list']= "Gunakake dhaftar ngisor iki kanggo ngawèhaké utawa lali pangguna kelompok ngakses kanggo komputer.";
$language['system']['user_this_wos']= "User Group iki this Wos";
$language['system']['back']= "Back";
$language['system']['user_descriotion']= "Gunakake dhaftar ngisor iki kanggo ngawèhaké utawa lali pangguna akses kanggo program ing komputer";
$language['system']['allowed_group']= "Groups diijini";
$language['system']['users_dnied']= "pangguna Ditolak";
$language['system']['programs_permission']= "program Idin";
$language['system']['deny_users']= "lali Pangguna";
$language['system']['new_password']= "Sandi New";
$language['system']['confirm_passowrd']= "konfirmasi Sandi";
$language['system']['captcha']= "Captcha";
$language['system']['set_time_zone']= "Set zona wektu";
$language['system']['reset_password']= "Reset Pangguna Sandi";
$language['system']['change_passwod_title']= "Kanggo ngganti tembung sandi, klik Reset Pangguna Sandi";
$language['system']['compress']= "compress";
$language['system']['back_restore']= "Serep utawa mbalèkaké file";
$language['system']['w0s_edition']= "Wos Edition";
$language['system']['system']= "sistem";
$language['system']['browser_information']= "Informasi browser";
$language['system']['my_computer']= "Komputer Kula";
$language['system']['select_zip_file']= "Pilih input Zip Gambar Instal program";

?>
