<?php

/*---------------------Ukrainian -----------------*/
$language =array();
$language['htmleditor']['file'] = 'файл';
$language['htmleditor']['new'] = 'новий';
$language['htmleditor']['open'] = 'відкрито';
$language['htmleditor']['save'] = 'зберігати';
$language['htmleditor']['import'] = 'імпорт';
$language['htmleditor']['export'] = 'експорт';
$language['htmleditor']['print'] = 'друк';
$language['htmleditor']['exit'] = 'вихід';

$language['htmleditor']['edit'] = 'редагувати';
$language['htmleditor']['undo'] = 'анулювати';
$language['htmleditor']['redo'] = 'переробляти';
$language['htmleditor']['copy'] = 'копія';
$language['htmleditor']['cut'] = 'вирізати';
$language['htmleditor']['paste'] = 'паста';

$language['htmleditor']['search'] = 'Пошук';
$language['htmleditor']['find'] = 'знайти';
$language['htmleditor']['findnext'] = 'знайти Далі';
$language['htmleditor']['findprev'] = 'знайти Попередня';
$language['htmleditor']['replace'] = 'замінювати';
$language['htmleditor']['replaceall'] = 'замінити всі';

$language['htmleditor']['view'] = 'вид';
$language['htmleditor']['markline'] = 'відзначити лінія';
$language['htmleditor']['deleteline'] = 'видалити лінію';
$language['htmleditor']['newline'] = 'Нова Лінія';
$language['htmleditor']['inserttab'] = 'вставте Tab';
$language['htmleditor']['fold'] = 'скласти';
$language['htmleditor']['unfold'] = 'розкриватися';
$language['htmleditor']['foldall'] = 'Згорнути все';
$language['htmleditor']['unfoldall'] = 'розкрити всі';

$language['htmleditor']['tools'] = 'інструменти';
$language['htmleditor']['comment'] = 'коментар';
$language['htmleditor']['uncomment'] = 'раськоментіруйте';
$language['htmleditor']['marktext'] = 'відзначити Текст';
$language['htmleditor']['removemark'] = 'видалити';
$language['htmleditor']['removeallmark'] = 'Видалити все Марка';
$language['htmleditor']['autoformat'] = 'авто Формат';
$language['htmleditor']['configuration'] = 'конфігурація';
$language['htmleditor']['options'] = 'опції';

$language['htmleditor']['help'] = 'Допоможіть';




$language['system']['control_panel'] = 'Панель управління';
$language['system']['adjust_settings_computer'] = 'Налаштуйте установки комп\'ютера';
$language['system']['security'] = 'безпеку';
$language['system']['folder_options'] = 'властивості папки';
$language['system']['backup'] = 'резервна копія';
$language['system']['programs'] = 'програми';
$language['system']['user_account'] = 'обліковий запис користувача';
$language['system']['appearance'] = 'зовнішній вигляд';
$language['system']['start_menu'] = 'меню Пуск';
$language['system']['system'] = 'система';
$language['system']['languages'] = 'мови';
$language['system']['fonts'] = 'шрифти';
$language['system']['date'] = 'дата';
$language['system']['configure_backup'] = 'Налаштування резервного копіювання даних';
$language['system']['select_location_store'] = 'Виберіть папку для зберігання.';
$language['system']['user'] = 'користувач';
$language['system']['create'] = 'створити';
$language['system']['new_local'] = 'новий локальний';
$language['system']['remove'] = 'видаляти';
$language['system']['next'] = 'видаляти';
$language['system']['cancel'] = 'скасувати';
$language['system']['program_list'] = 'список програм';
$language['system']['install'] = 'встановлювати';
$language['system']['store'] = 'магазин';
$language['system']['name'] = 'ім\'я';
$language['system']['group'] = 'група';
$language['system']['user_account_settings'] = 'Налаштування облікового запису користувача';
$language['system']['user_group_account_settings'] = 'Налаштування облікового запису групи користувачів';
$language['system']['new_user'] = 'новий користувач';
$language['system']['reset'] = 'скидання';
$language['system']['new_group'] = 'нова група';
$language['system']['parent_group'] = 'батьківська група';
$language['system']['add_user_title'] = 'У наведеному нижче списку, щоб надати або заборонити користувачам доступ до комп\'ютера і скидання паролів.';
$language['system']['permission'] = 'дозвіл';
$language['system']['permission_group'] = 'група дозволів';
$language['system']['update_available'] = 'важливі оновлення доступні';
$language['system']['optional_available'] = 'додаткові оновлення доступні';
$language['system']['system_information'] = 'інформаційна система';
$language['system']['operation_system'] = 'операційна система';
$language['system']['version'] = 'версія';
$language['system']['memory_usage'] = 'використання пам\'яті';
$language['system']['peak_memory_usage'] = 'Пік використання пам\'яті';
$language['system']['browser_name'] = 'назва браузера';
$language['system']['plataform'] = 'платформа';
$language['system']['system_languages'] = 'мови системи';
$language['system']['title_language_system'] = 'Використовується для зміни мови системи.';
$language['system']['new_font'] = 'новий шрифт';
$language['system']['path'] = 'шлях';
$language['system']['time'] = 'час';
$language['system']['change_date'] = 'дата зміни';
$language['system']['change_timezone'] = 'зміна часового поясу';
$language['system']['title_change_date'] = 'Встановіть дату і розклад';
$language['system']['time_zone'] = 'часовий пояс';
$language['system']['current_date_hours'] = 'Поточні дати та години';
$language['system']['desktop'] = 'робочий стіл';
$language['system']['library'] = 'бібліотека';
$language['system']['documents'] = 'документи';
$language['system']['images'] = 'зображень';
$language['system']['musics'] = 'Гурджиєва';
$language['system']['videos'] = 'відео';
$language['system']['login_settings'] = 'настройки входу';
$language['system']['login_type'] = 'Ввійти Тип';
$language['system']['login_encrypt'] = 'Ввійти шифрувати';
$language['system']['number_bits'] = 'кількість бітів';
$language['system']['number_attemps'] = 'спроби число';
$language['system']['password_force'] = 'пароль сила';
$language['system']['enable_security_question'] = 'включити питання безпеки';
$language['system']['enable_capctha'] = 'включити капчу';
$language['system']['capctha_type'] = 'тип CAPTCHA,';
$language['system']['change'] = 'зміна';
$language['system']['poor'] = 'бідних';
$language['system']['good'] = 'добре';
$language['system']['excellent'] = 'відмінно';
$language['system']['search'] = 'пошук';
$language['system']['custom_settings'] = 'призначені для користувача настройки';
$language['system']['change_theme'] = 'зміна теми';
$language['system']['change_account_image'] = 'рахунок зміни зображення';
$language['system']['change_mouse_icon'] = 'Значок зміни миші';
$language['system']['theme_settings'] = 'настройки теми';
$language['system']['create_theme_folder'] = 'створити папку теми';
$language['system']['add_theme_from_wos'] = 'додати тему з WOS';
$language['system']['upload_from_computer'] = 'завантажити з комп\'ютера';
$language['system']['set'] = 'комплект';
$language['system']['title_install'] = 'Ласкаво просимо в майстер установки програми';
$language['system']['description_install'] = 'Майстер установки допоможе вам змінити, виправити, і видалити програму.';
$language['system']['extract'] = 'екстракт';


$language['system']['ok']= 'добре';
$language['system']['Email']= "E-mail";
$language['system']['login']= "Ввійти"; 
$language['system']['password']= "пароль";
$language['system']['choose_mouse']= "Виберіть значок миші для вашого облікового запису";
$language['system']['chouse_mouse_description']= "Обраний значок миші з'явиться на екрані";
$language['system']['search_wos']= "Пошук в WOS";
$language['system']['change_image']= "змінити зображення";
$language['system']['upload_from_your_co´puter']= "Завантажити з вашого комп'ютера";
$language['system']['choose_new_picture']= "Виберіть нове зображення для вашого облікового запису";
$language['system']['choose_new_picture_description']= "Вибране зображення з'явиться на екрані входу в систему";
$language['system']['repeat']= "повторення";
$language['system']['title_user_list']= "У наведеному нижче списку, щоб надати або заборонити користувачам групи доступу до комп'ютера.";
$language['system']['user_this_wos']= "Група користувачів це Wos";
$language['system']['back']= "назад";
$language['system']['user_descriotion']= "У наведеному нижче списку, щоб надати або заборонити користувачам доступ до програм в комп'ютері.";
$language['system']['allowed_group']= "дозволені групи";
$language['system']['users_dnied']= "користувачі Denied";
$language['system']['programs_permission']= "програми Дозвіл";
$language['system']['deny_users']= "заборонити користувачам";
$language['system']['new_password']= "новий пароль";
$language['system']['confirm_passowrd']= "підтвердження пароля";
$language['system']['captcha']= "Захисний код";
$language['system']['set_time_zone']= "Налаштування часового поясу";
$language['system']['reset_password']= "Скинути пароль";
$language['system']['change_passwod_title']= "Щоб змінити пароль, натисніть кнопку Скинути пароль";
$language['system']['compress']= "стискати";
$language['system']['back_restore']= "Створення резервних копій та відновлення файлів";
$language['system']['w0s_edition']= "вос видання";
$language['system']['system']= "система";
$language['system']['browser_information']= "браузер даних";
$language['system']['my_computer']= "Мій комп'ютер";
$language['system']['select_zip_file']= "Виберіть вхід Zip-файл для установки програми";


?>
