<?php

/*------------CZECH -------------------*/
$language =array();
$language['htmleditor']['file'] = 'Soubor';
$language['htmleditor']['new'] = 'Nový';
$language['htmleditor']['open'] = 'Otevřený';
$language['htmleditor']['save'] = 'Ušetřit';
$language['htmleditor']['import'] = 'Dovozní';
$language['htmleditor']['export'] = 'Vývozní';
$language['htmleditor']['print'] = 'Tisk';
$language['htmleditor']['exit'] = 'Výjezd';

$language['htmleditor']['edit'] = 'Editovat';
$language['htmleditor']['undo'] = 'Zrušit';
$language['htmleditor']['redo'] = 'Předělat';
$language['htmleditor']['copy'] = 'kopie';
$language['htmleditor']['cut'] = 'řez';
$language['htmleditor']['paste'] = 'Pasta';

$language['htmleditor']['search'] = 'vyhledávání';
$language['htmleditor']['find'] = 'najít';
$language['htmleditor']['findnext'] = 'najít další';
$language['htmleditor']['findprev'] = 'najít Předchozí';
$language['htmleditor']['replace'] = 'vyměnit';
$language['htmleditor']['replaceall'] = 'nahradit vše';

$language['htmleditor']['view'] = 'pohled';
$language['htmleditor']['markline'] = 'Mark linka';
$language['htmleditor']['deleteline'] = 'Smazat řádek';
$language['htmleditor']['newline'] = 'Nový režim Line';
$language['htmleditor']['inserttab'] = 'Vložit Tab';
$language['htmleditor']['fold'] = 'složit';
$language['htmleditor']['unfold'] = 'rozvinout';
$language['htmleditor']['foldall'] = 'Přeložte Vše';
$language['htmleditor']['unfoldall'] = 'rozvinout vše';

$language['htmleditor']['tools'] = 'Nářadí';
$language['htmleditor']['comment'] = 'komentář';
$language['htmleditor']['uncomment'] = 'odkomentovat';
$language['htmleditor']['marktext'] = 'Značka textu';
$language['htmleditor']['removemark'] = 'Odstranit Mark';
$language['htmleditor']['removeallmark'] = 'Odebrat vše Mark';
$language['htmleditor']['autoformat'] = 'Auto Format';
$language['htmleditor']['configuration'] = 'Konfigurace';
$language['htmleditor']['options'] = 'Možnosti';

$language['htmleditor']['help'] = 'Pomoc';

$language['system']['control_panel'] = 'Kontrolní panel';
$language['system']['adjust_settings_computer'] = 'Upravte nastavení na počítači';
$language['system']['security'] = 'bezpečnostní';
$language['system']['folder_options'] = 'možnosti složky';
$language['system']['backup'] = 'zálohování';
$language['system']['programs'] = ' pořady';
$language['system']['user_account'] = 'Uživatelský účet';
$language['system']['appearance'] = 'vzhled';
$language['system']['start_menu'] = 'start menu';
$language['system']['system'] = 'systém';
$language['system']['languages'] = 'jazyky';
$language['system']['fonts'] = 'fonty';
$language['system']['date'] = 'datum';
$language['system']['configure_backup'] = 'Konfigurace zálohování';
$language['system']['select_location_store'] = 'Vyberte umístění pro uložení.';
$language['system']['user'] = 'uživatel ';
$language['system']['create'] = 'Vytvoření';
$language['system']['new_local'] = 'Nová místní';
$language['system']['remove'] = 'odebrat';
$language['system']['next'] = 'další';
$language['system']['cancel'] = 'zrušit';
$language['system']['program_list'] = 'seznam programů';
$language['system']['install'] = 'instalovat';
$language['system']['store'] = 'obchod';
$language['system']['name'] = 'jméno';
$language['system']['group'] = 'skupina';
$language['system']['user_account_settings'] = 'Nastavení uživatelských účtů';
$language['system']['user_group_account_settings'] = 'Nastavení účtu uživatelské skupiny';
$language['system']['new_user'] = 'nový uživatel';
$language['system']['reset'] = 'resetovat';
$language['system']['new_group'] = 'nová skupina';
$language['system']['parent_group'] = ' mateřská skupina';
$language['system']['add_user_title'] = 'Pomocí seznamu níže udělit nebo odepřít uživatelům přístup k počítači a reset hesla.';
$language['system']['permission'] = 'povolení';
$language['system']['permission_group'] = 'oprávnění skupiny';
$language['system']['update_available'] = 'důležité aktualizace jsou k dispozici';
$language['system']['optional_available'] = 'Volitelné aktualizace jsou k dispozici';
$language['system']['system_information'] = 'informační systém';
$language['system']['operation_system'] = 'operační systém';
$language['system']['version'] = 'Verze';
$language['system']['memory_usage'] = 'využití paměti';
$language['system']['peak_memory_usage'] = 'špička využití paměti';
$language['system']['browser_name'] = 'název prohlížeče';
$language['system']['plataform'] = 'plošina';
$language['system']['system_languages'] = 'jazykový systém';
$language['system']['title_language_system'] = 'Používá se pro změnu jazyka systému.';
$language['system']['new_font'] = 'nový font';
$language['system']['path'] = 'cesta';
$language['system']['time'] = 'čas';
$language['system']['change_date'] = 'datum změny';
$language['system']['change_timezone'] = 'změna časové pásmo';
$language['system']['title_change_date'] = 'Nastavte datum a plán';
$language['system']['time_zone'] = 'časové pásmo';
$language['system']['current_date_hours'] = 'Aktuální data a hodiny';
$language['system']['desktop'] = 'desktop';
$language['system']['library'] = 'knihovna';
$language['system']['documents'] = 'dokumenty';
$language['system']['images'] = 'obrazy';
$language['system']['musics'] = ' hudební skladby';
$language['system']['videos'] = 'videa';
$language['system']['login_settings'] = 'nastavení přihlašovacích';
$language['system']['login_type'] = 'přihlásit typ ';
$language['system']['login_encrypt'] = 'přihlášení šifrování';
$language['system']['number_bits'] = 'počet bitů';
$language['system']['number_attemps'] = 'pokusy číslo';
$language['system']['password_force'] = 'heslo síla';
$language['system']['enable_security_question'] = 'aktivovat bezpečnostní otázku';
$language['system']['enable_capctha'] = 'povolit captcha';
$language['system']['capctha_type'] = 'Typ captcha';
$language['system']['change'] = 'přeměna';
$language['system']['poor'] = 'chudý';
$language['system']['good'] = 'dobrý';
$language['system']['excellent'] = 'vynikající';
$language['system']['search'] = ' vyhledávání';
$language['system']['custom_settings'] = 'Vlastní nastavení';
$language['system']['change_theme'] = 'změnit vzhled';
$language['system']['change_account_image'] = 'Účet image změna';
$language['system']['change_mouse_icon'] = 'ikona změna myš';
$language['system']['theme_settings'] = 'nastavení téma';
$language['system']['create_theme_folder'] = 'Vytvoření motivu složku';
$language['system']['add_theme_from_wos'] = 'přidat motiv z WOS';
$language['system']['upload_from_computer'] = 'nahrát z počítače';
$language['system']['set'] = 'soubor';
$language['system']['title_install'] = 'Vítejte v instalačním průvodci programy';
$language['system']['description_install'] = 'Průvodce instalací vám pomůže pozměnit, opravit a odebrat program.';
$language['system']['extract'] = 'výtažek';



$language['system']['ok']= 'OK';
$language['system']['Email']= "E-mail";
$language['system']['login']= "přihlásit se"; 
$language['system']['password']= "heslo";
$language['system']['choose_mouse']= "Zvolit ikonu myši pro váš účet";
$language['system']['chouse_mouse_description']= "objeví se na obrazovce ikona vybrána myš";
$language['system']['search_wos']= "Vyhledávání v WOS";
$language['system']['change_image']= "změna Image";
$language['system']['upload_from_your_co´puter']= "Nahrát z počítače";
$language['system']['choose_new_picture']= "Vyberte si nový obrázek pro svůj účet";
$language['system']['choose_new_picture_description']= "Vybraný snímek se zobrazí na přihlašovací obrazovce";
$language['system']['repeat']= "opakovat";
$language['system']['title_user_list']= "Pomocí seznamu níže udělit nebo odepřít uživatelům skupiny přístup k počítači.";
$language['system']['user_this_wos']= "User Group To Wos";
$language['system']['back']= "Zadní";
$language['system']['user_descriotion']= "Pomocí seznamu níže udělit nebo odepřít uživatelům přístup k programům v počítači.";
$language['system']['allowed_group']= "Povolené skupiny";
$language['system']['users_dnied']= "uživatelé odepřen";
$language['system']['programs_permission']= "programy Povolení";
$language['system']['deny_users']= "Deny uživatelé";
$language['system']['new_password']= "nové heslo";
$language['system']['confirm_passowrd']= "Potvrďte heslo";
$language['system']['captcha']= "Captcha";
$language['system']['set_time_zone']= "Nastavit časové pásmo";
$language['system']['reset_password']= "Obnovit heslo";
$language['system']['change_passwod_title']= "Chcete-li změnit heslo, klepněte na tlačítko Obnovit heslo";
$language['system']['compress']= "komprimovat";
$language['system']['back_restore']= "Zálohování nebo obnovení souborů";
$language['system']['w0s_edition']= "Wos Edition";
$language['system']['system']= "Systém";
$language['system']['browser_information']= "Informace browser";
$language['system']['my_computer']= "Můj počítač";
$language['system']['select_zip_file']= "Vyberte funkci vstupní Zip File nainstalovat program";




?>
